import { useQuery, useMutation } from "@tanstack/react-query";
import { EngagementSettings } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { InfoIcon } from "lucide-react";

export function EngagementAutomation() {
  const { toast } = useToast();
  
  const { data: settings, isLoading } = useQuery<EngagementSettings>({
    queryKey: ["/api/engagement-settings"],
  });
  
  const updateSettingsMutation = useMutation({
    mutationFn: async (data: Partial<EngagementSettings>) => {
      const res = await apiRequest("PUT", "/api/engagement-settings", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/engagement-settings"] });
      toast({
        title: "Settings Updated",
        description: "Your engagement automation settings have been saved",
      });
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: error instanceof Error ? error.message : "Failed to update settings",
        variant: "destructive",
      });
    },
  });
  
  const handleMainToggle = (checked: boolean) => {
    updateSettingsMutation.mutate({
      autoComments: checked,
      autoLikes: checked,
    });
  };
  
  const handleCommentsToggle = (checked: boolean) => {
    updateSettingsMutation.mutate({
      autoComments: checked,
    });
  };
  
  const handleLikesToggle = (checked: boolean) => {
    updateSettingsMutation.mutate({
      autoLikes: checked,
    });
  };
  
  const updateCommentSettings = (field: keyof EngagementSettings, value: boolean) => {
    updateSettingsMutation.mutate({
      [field]: value,
    });
  };
  
  if (isLoading) {
    return (
      <div className="mt-6 bg-white rounded-lg shadow-sm p-4">
        <div className="flex items-center justify-between mb-4">
          <Skeleton className="h-7 w-48" />
          <Skeleton className="h-6 w-12" />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-40 w-full" />
          ))}
        </div>
      </div>
    );
  }
  
  if (!settings) {
    return null;
  }
  
  // Calculate usage percentages for progress bars
  const commentsUsage = 0; // In a real app, this would come from the API
  const likesUsage = 43; // In a real app, this would come from the API
  const followsUsage = 12; // In a real app, this would come from the API
  
  const commentsPercentage = (commentsUsage / settings.dailyCommentLimit) * 100;
  const likesPercentage = (likesUsage / settings.dailyLikeLimit) * 100;
  const followsPercentage = (followsUsage / settings.dailyFollowLimit) * 100;
  
  return (
    <div className="mt-6 bg-white rounded-lg shadow-sm p-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-semibold text-lg">Engagement Automation</h2>
        <Switch
          checked={settings.autoComments || settings.autoLikes}
          onCheckedChange={handleMainToggle}
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="border rounded-lg p-3">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-medium text-sm">Auto Comments</h3>
            <Switch
              id="comment-toggle"
              checked={settings.autoComments}
              onCheckedChange={handleCommentsToggle}
              size="sm"
            />
          </div>
          
          <p className="text-xs text-gray-500 mb-2">Automatically respond to comments using AI</p>
          
          <div className="space-y-2">
            <div className="flex items-center">
              <Checkbox
                id="comment-positive"
                checked={settings.commentPositiveMentions}
                onCheckedChange={(checked) => 
                  updateCommentSettings('commentPositiveMentions', checked as boolean)
                }
                className="mr-2"
              />
              <Label htmlFor="comment-positive" className="text-xs">Positive mentions</Label>
            </div>
            <div className="flex items-center">
              <Checkbox
                id="comment-questions"
                checked={settings.commentQuestions}
                onCheckedChange={(checked) => 
                  updateCommentSettings('commentQuestions', checked as boolean)
                }
                className="mr-2"
              />
              <Label htmlFor="comment-questions" className="text-xs">Product questions</Label>
            </div>
            <div className="flex items-center">
              <Checkbox
                id="comment-negative"
                checked={settings.commentNegativeFeedback}
                onCheckedChange={(checked) => 
                  updateCommentSettings('commentNegativeFeedback', checked as boolean)
                }
                className="mr-2"
              />
              <Label htmlFor="comment-negative" className="text-xs">Negative feedback</Label>
            </div>
          </div>
          
          <div className="mt-3">
            <Button variant="link" className="text-xs text-[#0095F6] p-0 h-auto">
              Edit Response Templates
            </Button>
          </div>
        </div>
        
        <div className="border rounded-lg p-3">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-medium text-sm">Auto Likes</h3>
            <Switch
              id="like-toggle"
              checked={settings.autoLikes}
              onCheckedChange={handleLikesToggle}
              size="sm"
            />
          </div>
          
          <p className="text-xs text-gray-500 mb-2">Auto-like content from specific sources</p>
          
          <div className="space-y-2">
            <div className="flex items-center">
              <Checkbox
                id="like-followers"
                checked={settings.likeFollowerPosts}
                onCheckedChange={(checked) =>
                  updateCommentSettings('likeFollowerPosts', checked as boolean)
                }
                className="mr-2"
              />
              <Label htmlFor="like-followers" className="text-xs">Posts from followers</Label>
            </div>
            <div className="flex items-center">
              <Checkbox
                id="like-hashtags"
                checked={settings.likeHashtags}
                onCheckedChange={(checked) =>
                  updateCommentSettings('likeHashtags', checked as boolean)
                }
                className="mr-2"
              />
              <Label htmlFor="like-hashtags" className="text-xs">Tracked hashtags</Label>
            </div>
            <div className="flex items-center">
              <Checkbox
                id="like-mentions"
                checked={settings.likeBrandMentions}
                onCheckedChange={(checked) =>
                  updateCommentSettings('likeBrandMentions', checked as boolean)
                }
                className="mr-2"
              />
              <Label htmlFor="like-mentions" className="text-xs">Brand mentions</Label>
            </div>
          </div>
          
          <div className="mt-3">
            <Button variant="link" className="text-xs text-[#0095F6] p-0 h-auto">
              Configure Hashtags
            </Button>
          </div>
        </div>
        
        <div className="border rounded-lg p-3">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-medium text-sm">Engagement Limits</h3>
            <div className="flex items-center">
              <InfoIcon className="h-3 w-3 text-gray-400" />
            </div>
          </div>
          
          <p className="text-xs text-gray-500 mb-2">Set safe limits to avoid Instagram restrictions</p>
          
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span>Daily comments ({settings.dailyCommentLimit})</span>
                <span>{commentsUsage}/{settings.dailyCommentLimit}</span>
              </div>
              <Progress value={commentsPercentage} className="h-1" />
            </div>
            
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span>Daily likes ({settings.dailyLikeLimit})</span>
                <span>{likesUsage}/{settings.dailyLikeLimit}</span>
              </div>
              <Progress value={likesPercentage} className="h-1" />
            </div>
            
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span>Daily follows ({settings.dailyFollowLimit})</span>
                <span>{followsUsage}/{settings.dailyFollowLimit}</span>
              </div>
              <Progress value={followsPercentage} className="h-1" />
            </div>
          </div>
          
          <div className="mt-3">
            <Button variant="link" className="text-xs text-[#0095F6] p-0 h-auto">
              Adjust Limits
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
