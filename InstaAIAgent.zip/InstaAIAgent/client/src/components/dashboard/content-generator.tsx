import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { WandSparkles, Loader2 } from "lucide-react";

const contentTypes = [
  { value: "product_promotion", label: "Product Promotion" },
  { value: "lifestyle", label: "Lifestyle" },
  { value: "behind_the_scenes", label: "Behind the Scenes" },
  { value: "educational", label: "Educational" },
  { value: "user_generated", label: "User Generated Content" },
];

const brandVoices = [
  { value: "professional", label: "Professional" },
  { value: "friendly", label: "Friendly" },
  { value: "casual", label: "Casual" },
];

const visualStyles = [
  {
    value: "minimalist",
    label: "Minimalist",
    imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&q=80"
  },
  {
    value: "colorful",
    label: "Colorful",
    imageUrl: "https://images.unsplash.com/photo-1560177112-fbfd5fde9566?w=500&q=80"
  }
];

export function ContentGenerator() {
  const { toast } = useToast();
  const [contentType, setContentType] = useState<string>("product_promotion");
  const [brandVoice, setBrandVoice] = useState<string>("professional");
  const [keyMessage, setKeyMessage] = useState<string>("");
  const [selectedStyle, setSelectedStyle] = useState<string>("minimalist");
  
  const generateMutation = useMutation({
    mutationFn: async (data: {
      contentType: string;
      brandVoice: string;
      keyMessage: string;
      visualStyle: string;
    }) => {
      const res = await apiRequest("POST", "/api/generate-content", data);
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Content Generated",
        description: "AI has created content based on your preferences",
      });
      
      // Invalidate post queries to refresh the list
      queryClient.invalidateQueries({ queryKey: ["/api/posts/scheduled"] });
    },
    onError: (error) => {
      toast({
        title: "Generation Failed",
        description: error instanceof Error ? error.message : "Failed to generate content",
        variant: "destructive",
      });
    },
  });
  
  const handleGenerate = () => {
    if (!keyMessage) {
      toast({
        title: "Missing Information",
        description: "Please enter a key message for your content",
        variant: "destructive",
      });
      return;
    }
    
    generateMutation.mutate({
      contentType,
      brandVoice,
      keyMessage,
      visualStyle: selectedStyle,
    });
  };
  
  return (
    <Card className="bg-white rounded-lg shadow-sm p-4">
      <h2 className="font-semibold text-lg mb-4">AI Content Generator</h2>
      
      <CardContent className="p-0 space-y-4">
        <div>
          <Label className="block text-sm font-medium mb-1">Content Type</Label>
          <Select value={contentType} onValueChange={setContentType}>
            <SelectTrigger className="w-full px-3 py-2 text-sm">
              <SelectValue placeholder="Select content type" />
            </SelectTrigger>
            <SelectContent>
              {contentTypes.map((type) => (
                <SelectItem key={type.value} value={type.value}>
                  {type.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <Label className="block text-sm font-medium mb-1">Brand Voice</Label>
          <div className="grid grid-cols-3 gap-2">
            {brandVoices.map((voice) => (
              <Button
                key={voice.value}
                type="button"
                variant="outline"
                size="sm"
                className={`px-3 py-1 text-xs ${
                  brandVoice === voice.value
                    ? "bg-[#0095F6] bg-opacity-10 text-[#0095F6] border-[#0095F6]"
                    : ""
                }`}
                onClick={() => setBrandVoice(voice.value)}
              >
                {voice.label}
              </Button>
            ))}
          </div>
        </div>
        
        <div>
          <Label className="block text-sm font-medium mb-1">Key Message</Label>
          <Textarea
            value={keyMessage}
            onChange={(e) => setKeyMessage(e.target.value)}
            className="w-full px-3 py-2 text-sm"
            rows={2}
            placeholder="What's the main point of this post?"
          />
        </div>
        
        <div>
          <Label className="block text-sm font-medium mb-1">Visual Style</Label>
          <div className="grid grid-cols-2 gap-2">
            {visualStyles.map((style) => (
              <div
                key={style.value}
                className={`border rounded-md overflow-hidden cursor-pointer hover:border-[#0095F6] transition-colors ${
                  selectedStyle === style.value ? "border-[#0095F6]" : ""
                }`}
                onClick={() => setSelectedStyle(style.value)}
              >
                <div className="h-16 bg-gray-200">
                  <img
                    src={style.imageUrl}
                    alt={`${style.label} style`}
                    className="h-full w-full object-cover"
                  />
                </div>
                <div className="p-1 text-center">
                  <p className="text-xs">{style.label}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="pt-2">
          <Button
            className="w-full py-2 bg-[#0095F6] text-white hover:bg-[#0095F6]/90"
            onClick={handleGenerate}
            disabled={generateMutation.isPending}
          >
            {generateMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Generating...
              </>
            ) : (
              <>
                <WandSparkles className="mr-2 h-4 w-4" /> Generate Content
              </>
            )}
          </Button>
        </div>
        
        <div className="pt-2 text-center">
          <p className="text-xs text-gray-500">
            AI will generate content based on your Instagram API rate limits
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
