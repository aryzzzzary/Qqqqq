import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Loader2, CheckCircle, AlertCircle, CreditCard, ArrowLeft } from "lucide-react";
import { SubscriptionPlan } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { StripeCheckout } from "@/components/payment/stripe-checkout";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";

export function SubscriptionManagement() {
  const { toast } = useToast();
  const [location, setLocation] = useLocation();
  const [selectedPlanId, setSelectedPlanId] = useState<number | null>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan | null>(null);
  
  // Check for successful payment return
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const success = params.get('success');
    const planId = params.get('plan');
    
    if (success === 'true' && planId) {
      toast({
        title: "Payment Successful",
        description: "Your subscription has been updated successfully.",
      });
      
      // Clear URL parameters
      window.history.replaceState({}, document.title, window.location.pathname);
      
      // Refresh subscription data
      queryClient.invalidateQueries({ queryKey: ["/api/subscription/status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/payments"] });
    }
  }, [toast]);
  
  const { data: plans, isLoading: isLoadingPlans } = useQuery<SubscriptionPlan[]>({
    queryKey: ["/api/subscription-plans"],
  });
  
  interface SubscriptionStatus {
    isActive: boolean;
    plan?: SubscriptionPlan;
    daysRemaining: number;
  }
  
  interface Payment {
    id: number;
    userId: number;
    amount: string;
    currency: string;
    status: string;
    planId: number;
    createdAt: string;
  }
  
  const { data: subscriptionStatus, isLoading: isLoadingStatus } = useQuery<SubscriptionStatus>({
    queryKey: ["/api/subscription/status"],
  });
  
  const { data: payments, isLoading: isLoadingPayments } = useQuery<Payment[]>({
    queryKey: ["/api/payments"],
  });

  const purchaseMutation = useMutation({
    mutationFn: async ({ planId, paymentMethod, amount }: { planId: number, paymentMethod: string, amount: string }) => {
      const res = await apiRequest("POST", "/api/subscription/purchase", {
        planId,
        paymentMethod,
        amount
      });
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Subscription updated",
        description: "Your subscription has been successfully updated."
      });
      queryClient.invalidateQueries({ queryKey: ["/api/subscription/status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/payments"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error updating subscription",
        description: error.message,
        variant: "destructive"
      });
    }
  });
  
  const handleSubscribe = (planId: number) => {
    const plan = plans?.find(p => p.id === planId);
    if (!plan) return;
    
    setSelectedPlan(plan);
    setSelectedPlanId(planId);
    setIsCheckoutOpen(true);
  };
  
  const handleCloseCheckout = () => {
    setIsCheckoutOpen(false);
    setSelectedPlan(null);
  };
  
  if (isLoadingPlans || isLoadingStatus) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  const currentPlanId = subscriptionStatus?.plan?.id;
  const isSubscriptionActive = subscriptionStatus?.isActive;
  const daysRemaining = subscriptionStatus?.daysRemaining || 0;
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2">
        <h2 className="text-2xl font-bold">Subscription Management</h2>
        
        {isSubscriptionActive && (
          <div className="mb-4 p-4 bg-primary/10 rounded-lg">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-primary" />
              <span className="font-medium">
                Active Subscription: {subscriptionStatus?.plan?.name}
              </span>
              <Badge variant="secondary">
                {daysRemaining} days remaining
              </Badge>
            </div>
          </div>
        )}
        
        {!isSubscriptionActive && (
          <div className="mb-4 p-4 bg-destructive/10 rounded-lg">
            <div className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-destructive" />
              <span className="font-medium">No active subscription</span>
            </div>
          </div>
        )}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {plans?.map((plan) => (
          <Card 
            key={plan.id} 
            className={`flex flex-col ${currentPlanId === plan.id ? 'border-primary' : ''}`}
          >
            <CardHeader>
              <CardTitle>{plan.name}</CardTitle>
              <CardDescription>
                ${plan.price}/{plan.billingCycle}
              </CardDescription>
            </CardHeader>
            
            <CardContent className="flex-grow">
              <ul className="space-y-2">
                {Array.isArray(plan.features) && plan.features.map((feature, i) => (
                  <li key={i} className="flex items-start">
                    <CheckCircle className="h-4 w-4 mr-2 text-primary" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            
            <CardFooter>
              <Button
                className="w-full"
                variant={currentPlanId === plan.id ? "outline" : "default"}
                disabled={purchaseMutation.isPending || currentPlanId === plan.id}
                onClick={() => handleSubscribe(plan.id)}
              >
                {purchaseMutation.isPending && selectedPlanId === plan.id ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : currentPlanId === plan.id ? (
                  "Current Plan"
                ) : (
                  <>
                    <CreditCard className="h-4 w-4 mr-2" />
                    Subscribe
                  </>
                )}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
      
      {payments && payments.length > 0 && (
        <div className="mt-8">
          <h3 className="text-xl font-semibold mb-4">Payment History</h3>
          <div className="border rounded-lg overflow-hidden">
            <table className="w-full">
              <thead className="bg-muted">
                <tr>
                  <th className="px-4 py-2 text-left">Date</th>
                  <th className="px-4 py-2 text-left">Amount</th>
                  <th className="px-4 py-2 text-left">Status</th>
                </tr>
              </thead>
              <tbody>
                {payments.map((payment) => (
                  <tr key={payment.id} className="border-t">
                    <td className="px-4 py-2">
                      {new Date(payment.createdAt).toLocaleDateString()}
                    </td>
                    <td className="px-4 py-2">
                      ${payment.amount} {payment.currency}
                    </td>
                    <td className="px-4 py-2">
                      <Badge variant={payment.status === "completed" ? "outline" : "secondary"}>
                        {payment.status}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      
      {/* Stripe Checkout Dialog */}
      <Dialog open={isCheckoutOpen} onOpenChange={(open) => !open && handleCloseCheckout()}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-8 w-8 rounded-full" 
                onClick={handleCloseCheckout}
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
              Checkout for {selectedPlan?.name} Plan
            </DialogTitle>
            <DialogDescription>
              Complete your subscription payment securely via Stripe.
            </DialogDescription>
          </DialogHeader>
          
          {selectedPlan && (
            <StripeCheckout
              planId={selectedPlan.id}
              planName={selectedPlan.name}
              planPrice={parseFloat(selectedPlan.price)}
              returnUrl={window.location.href}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}