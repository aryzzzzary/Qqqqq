import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { Post } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { PlusIcon, Pencil, Trash2, Calendar } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export function UpcomingPosts() {
  const { toast } = useToast();
  const [postToDelete, setPostToDelete] = useState<number | null>(null);
  
  const { data: posts, isLoading } = useQuery<Post[]>({
    queryKey: ["/api/posts/scheduled"],
  });
  
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/posts/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts/scheduled"] });
      toast({
        title: "Post deleted",
        description: "The scheduled post has been removed",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to delete post",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    },
  });
  
  const handleDelete = (id: number) => {
    setPostToDelete(id);
  };
  
  const confirmDelete = () => {
    if (postToDelete) {
      deleteMutation.mutate(postToDelete);
      setPostToDelete(null);
    }
  };
  
  const getPostStatusBadge = (status: string) => {
    switch (status) {
      case "ready":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Ready</Badge>;
      case "draft":
        return <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100">Draft</Badge>;
      case "ai_generated":
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">AI Generated</Badge>;
      case "posted":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Posted</Badge>;
      case "failed":
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Failed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };
  
  const getPostTypeBadge = (contentType: string) => {
    switch (contentType) {
      case "image":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Image</Badge>;
      case "video":
        return <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-100">Video</Badge>;
      case "carousel":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Carousel</Badge>;
      default:
        return <Badge variant="outline">{contentType}</Badge>;
    }
  };
  
  const formatScheduleDate = (date: string | Date | null) => {
    if (!date) return "Not scheduled";
    
    const scheduleDate = new Date(date);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    if (scheduleDate.toDateString() === today.toDateString()) {
      return `Today, ${scheduleDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    } else if (scheduleDate.toDateString() === tomorrow.toDateString()) {
      return `Tomorrow, ${scheduleDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    } else {
      return scheduleDate.toLocaleDateString([], { 
        month: 'short', 
        day: 'numeric', 
        hour: '2-digit', 
        minute: '2-digit' 
      });
    }
  };
  
  if (isLoading) {
    return (
      <div className="lg:col-span-2 bg-white rounded-lg shadow-sm p-4">
        <div className="flex items-center justify-between mb-4">
          <Skeleton className="h-7 w-36" />
          <Skeleton className="h-9 w-32" />
        </div>
        
        <div className="overflow-x-auto">
          <Skeleton className="h-52 w-full" />
        </div>
      </div>
    );
  }
  
  return (
    <div className="lg:col-span-2 bg-white rounded-lg shadow-sm p-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-semibold text-lg">Upcoming Posts</h2>
        <Link href="/scheduling">
          <Button className="text-sm px-3 py-1 bg-[#0095F6] text-white hover:bg-[#0095F6]/90">
            <PlusIcon className="h-4 w-4 mr-1" /> New Post
          </Button>
        </Link>
      </div>
      
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-sm font-medium text-gray-500">Content</TableHead>
              <TableHead className="text-sm font-medium text-gray-500">Type</TableHead>
              <TableHead className="text-sm font-medium text-gray-500">Schedule</TableHead>
              <TableHead className="text-sm font-medium text-gray-500">Status</TableHead>
              <TableHead className="text-sm font-medium text-gray-500">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {posts && posts.length > 0 ? (
              posts.map((post) => (
                <TableRow key={post.id}>
                  <TableCell className="py-3">
                    <div className="flex items-center">
                      <div className="h-10 w-10 rounded bg-gray-200 flex-shrink-0">
                        {post.thumbnailUrl ? (
                          <img 
                            src={post.thumbnailUrl} 
                            alt={`Preview for ${post.caption.substring(0, 20)}...`}
                            className="h-full w-full object-cover rounded"
                          />
                        ) : (
                          <div className="h-full w-full flex items-center justify-center text-gray-400">
                            <Calendar className="h-5 w-5" />
                          </div>
                        )}
                      </div>
                      <div className="ml-3">
                        <p className="text-sm font-medium">
                          {post.caption.length > 30
                            ? `${post.caption.substring(0, 30)}...`
                            : post.caption}
                        </p>
                        <p className="text-xs text-gray-500 truncate w-48">
                          {post.caption.length > 50
                            ? `${post.caption.substring(0, 50)}...`
                            : post.caption}
                        </p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="py-3">
                    {getPostTypeBadge(post.contentType)}
                  </TableCell>
                  <TableCell className="py-3">
                    <p className="text-sm">{formatScheduleDate(post.scheduledAt)}</p>
                  </TableCell>
                  <TableCell className="py-3">
                    {getPostStatusBadge(post.status)}
                  </TableCell>
                  <TableCell className="py-3">
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="icon" className="text-gray-500 hover:text-[#0095F6]">
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <AlertDialog open={postToDelete === post.id} onOpenChange={(open) => !open && setPostToDelete(null)}>
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-gray-500 hover:text-[#DC3545]"
                            onClick={() => handleDelete(post.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Post</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to delete this scheduled post? 
                              This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={confirmDelete}
                              className="bg-red-500 hover:bg-red-600"
                            >
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-6 text-gray-500">
                  No upcoming posts scheduled. Click "New Post" to create one.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
      
      {posts && posts.length > 0 && (
        <div className="mt-4 text-center">
          <Link href="/scheduling">
            <Button variant="link" className="text-sm text-[#0095F6] hover:underline">
              View All Scheduled Posts
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
}
