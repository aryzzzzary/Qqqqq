import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { InstagramApiStatus } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { RefreshCw, AlertTriangle } from "lucide-react";

export function SecurityModule() {
  const { toast } = useToast();
  
  const { data, isLoading, refetch } = useQuery<InstagramApiStatus>({
    queryKey: ["/api/instagram/status"],
  });
  
  const handleRefreshTokens = () => {
    toast({
      title: "Token Refresh",
      description: "In a production app, this would refresh your Instagram API tokens.",
    });
  };
  
  if (isLoading) {
    return (
      <div className="mt-6 bg-white rounded-lg shadow-sm p-4">
        <div className="flex items-center justify-between mb-4">
          <Skeleton className="h-7 w-48" />
          <Skeleton className="h-9 w-32" />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-40 w-full" />
        </div>
        
        <Skeleton className="h-16 w-full mt-4" />
      </div>
    );
  }
  
  if (!data) {
    return null;
  }
  
  // In a real app, this would come from the API
  const tokenExpiryDays = 59;
  const twoFactorEnabled = true;
  const lastAccessTime = "Today, 10:45 AM";
  
  return (
    <div className="mt-6 bg-white rounded-lg shadow-sm p-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-semibold text-lg">Security & Credentials</h2>
        <Button
          variant="ghost"
          className="text-sm text-[#0095F6] hover:text-[#0095F6]/80"
          onClick={handleRefreshTokens}
        >
          <RefreshCw className="h-4 w-4 mr-1" /> Refresh Tokens
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="border rounded-lg">
          <CardContent className="p-3">
            <h3 className="font-medium text-sm mb-2">API Access Status</h3>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-xs">Instagram Graph API</span>
                <Badge className="text-xs px-2 py-1 bg-green-100 text-green-800">
                  {data.connected ? "Active" : "Inactive"}
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs">Scope: business_management</span>
                <Badge className="text-xs px-2 py-1 bg-green-100 text-green-800">
                  Granted
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs">Scope: instagram_basic</span>
                <Badge className="text-xs px-2 py-1 bg-green-100 text-green-800">
                  Granted
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs">Scope: instagram_content_publish</span>
                <Badge className="text-xs px-2 py-1 bg-green-100 text-green-800">
                  Granted
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs">Scope: instagram_manage_comments</span>
                <Badge className="text-xs px-2 py-1 bg-green-100 text-green-800">
                  Granted
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border rounded-lg">
          <CardContent className="p-3">
            <h3 className="font-medium text-sm mb-2">Authentication</h3>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-xs">Token Expiration</span>
                <span className="text-xs">{tokenExpiryDays} days remaining</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs">Two-Factor Authentication</span>
                <Badge className="text-xs px-2 py-1 bg-green-100 text-green-800">
                  {twoFactorEnabled ? "Enabled" : "Disabled"}
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs">Last Access</span>
                <span className="text-xs">{lastAccessTime}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs">Access Log</span>
                <Button variant="link" className="text-xs text-[#0095F6] p-0 h-auto">
                  View
                </Button>
              </div>
              <div className="mt-2">
                <Button
                  variant="outline"
                  className="w-full py-1.5 text-xs border border-[#0095F6] text-[#0095F6] hover:bg-[#0095F6] hover:bg-opacity-10"
                >
                  Manage Authentication Settings
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
        <div className="flex">
          <AlertTriangle className="text-yellow-500 h-4 w-4 mr-2 flex-shrink-0" />
          <div>
            <p className="text-xs text-yellow-700">
              Your API credentials are securely stored and encrypted. Credentials expire in {tokenExpiryDays} days - we'll remind you when it's time to refresh your tokens.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
