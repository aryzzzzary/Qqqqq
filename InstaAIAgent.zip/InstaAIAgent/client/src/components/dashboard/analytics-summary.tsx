import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { InstagramAnalytics } from "@shared/schema";
import { Calendar, ArrowUp, ArrowDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { LineChart } from "@/components/ui/line-chart";

export function AnalyticsSummary() {
  const [period, setPeriod] = useState<string>("7");
  
  const { data, isLoading } = useQuery<InstagramAnalytics>({
    queryKey: ["/api/analytics", { days: period }],
  });
  
  const handlePeriodChange = (value: string) => {
    setPeriod(value);
  };
  
  const renderMetricCard = (
    title: string,
    value: number | string,
    change: number,
    data: number[]
  ) => {
    return (
      <Card className="bg-white rounded-lg shadow-sm p-4">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm text-gray-500">{title}</p>
            <h3 className="text-2xl font-semibold">{value}</h3>
          </div>
          <div className={`flex items-center text-sm ${change >= 0 ? "text-[#28A745]" : "text-[#DC3545]"}`}>
            {change >= 0 ? (
              <ArrowUp className="mr-1 h-4 w-4" />
            ) : (
              <ArrowDown className="mr-1 h-4 w-4" />
            )}
            <span>{Math.abs(change)}%</span>
          </div>
        </div>
        <div className="mt-3 h-10">
          <LineChart data={data} />
        </div>
      </Card>
    );
  };
  
  if (isLoading) {
    return (
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <Skeleton className="h-7 w-48" />
          <Skeleton className="h-9 w-32" />
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-36 w-full" />
          ))}
        </div>
      </div>
    );
  }
  
  if (!data) {
    return null;
  }
  
  // Sample chart data - in a real app this would come from the API
  const mockChartData = {
    followers: [10, 12, 15, 14, 16, 18, 20],
    engagement: [5, 7, 6, 8, 7, 9, 8],
    reach: [40, 42, 45, 48, 51, 53, 55],
    visits: [30, 28, 26, 29, 32, 35, 38]
  };
  
  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-semibold text-lg">Analytics Overview</h2>
        <div className="flex items-center">
          <Select value={period} onValueChange={handlePeriodChange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">Last 7 days</SelectItem>
              <SelectItem value="14">Last 14 days</SelectItem>
              <SelectItem value="30">Last 30 days</SelectItem>
              <SelectItem value="90">Last 3 months</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {renderMetricCard(
          "Followers",
          data.followers.count.toLocaleString(),
          data.followers.change,
          mockChartData.followers
        )}
        
        {renderMetricCard(
          "Engagement",
          `${data.engagement.rate}%`,
          data.engagement.change,
          mockChartData.engagement
        )}
        
        {renderMetricCard(
          "Post Reach",
          data.postReach.count >= 1000 
            ? `${(data.postReach.count / 1000).toFixed(1)}K` 
            : data.postReach.count.toString(),
          data.postReach.change,
          mockChartData.reach
        )}
        
        {renderMetricCard(
          "Profile Visits",
          data.profileVisits.count.toLocaleString(),
          data.profileVisits.change,
          mockChartData.visits
        )}
      </div>
    </div>
  );
}
