import { useQuery } from "@tanstack/react-query";
import { InstagramApiStatus } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { RefreshCw } from "lucide-react";

export function ConnectionStatus() {
  const { toast } = useToast();
  
  const { data, isLoading, error, refetch } = useQuery<InstagramApiStatus>({
    queryKey: ["/api/instagram/status"],
    refetchInterval: 60000, // Refresh every minute
  });
  
  const handleReconnect = async () => {
    try {
      // In a real app, this would redirect to Instagram OAuth
      toast({
        title: "Instagram Auth",
        description: "You would be redirected to Instagram for authentication",
      });
    } catch (error) {
      toast({
        title: "Connection failed",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive",
      });
    }
  };
  
  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div className="flex flex-wrap items-center justify-between mb-4">
          <div>
            <Skeleton className="h-6 w-56 mb-2" />
            <Skeleton className="h-4 w-36" />
          </div>
          <Skeleton className="h-8 w-32" />
        </div>
        
        <div className="space-y-4">
          <Skeleton className="h-16 w-full" />
          <Skeleton className="h-16 w-full" />
        </div>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div className="text-center p-4">
          <p className="text-red-500 mb-2">Failed to load Instagram connection status</p>
          <Button onClick={() => refetch()}>Retry</Button>
        </div>
      </div>
    );
  }
  
  if (!data) {
    return null;
  }
  
  return (
    <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
      <div className="flex flex-wrap items-center justify-between">
        <div>
          <h2 className="font-semibold text-lg">Instagram API Connection</h2>
          <p className="text-sm text-gray-500">
            Business Account: {data.businessAccount || "Not connected"}
          </p>
        </div>
        <div className="flex items-center space-x-2 mt-2 md:mt-0">
          {data.connected ? (
            <>
              <span className="inline-block w-3 h-3 rounded-full bg-[#28A745]"></span>
              <span className="text-sm font-medium">Connected</span>
            </>
          ) : (
            <>
              <span className="inline-block w-3 h-3 rounded-full bg-[#DC3545]"></span>
              <span className="text-sm font-medium">Disconnected</span>
            </>
          )}
          <Button
            variant="ghost" 
            size="sm" 
            className="ml-2 text-sm text-[#0095F6] hover:text-[#0095F6]/80"
            onClick={handleReconnect}
          >
            {data.connected ? "Reconnect" : "Connect"}
          </Button>
        </div>
      </div>
      
      {data.connected && (
        <div className="mt-4">
          <div className="flex items-center justify-between py-2 border-b">
            <span className="text-sm">API Rate Limit</span>
            <div className="w-48">
              <Progress 
                value={(data.rateLimit.used / data.rateLimit.total) * 100} 
                className="h-2 rounded-full bg-gray-200"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>{data.rateLimit.used}/{data.rateLimit.total} requests</span>
                <span>Resets in {data.rateLimit.resetsIn}</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center justify-between py-2 border-b">
            <span className="text-sm">Content Quota</span>
            <div className="w-48">
              <Progress 
                value={(data.contentQuota.used / data.contentQuota.total) * 100}
                className="h-2 rounded-full bg-gray-200"
                indicatorClassName="bg-[#FFC107]"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>{data.contentQuota.used}/{data.contentQuota.total} posts</span>
                <span>{data.contentQuota.period}</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center justify-between py-2">
            <span className="text-sm">Last Sync</span>
            <div className="flex items-center">
              <span className="text-sm text-gray-500 mr-2">{data.lastSync}</span>
              <Button variant="ghost" size="icon" className="h-5 w-5" onClick={() => refetch()}>
                <RefreshCw className="h-3 w-3" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
