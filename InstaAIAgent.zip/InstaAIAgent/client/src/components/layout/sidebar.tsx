import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import {
  BarChart,
  Calendar,
  Image,
  MessageSquare,
  Lock,
  Settings,
  LayoutDashboard,
  CreditCard,
  BookOpen,
  Database,
  Lightbulb,
} from "lucide-react";
import { Button } from "@/components/ui/button";

const navItems = [
  {
    title: "Dashboard",
    href: "/dashboard",
    icon: LayoutDashboard,
  },
  {
    title: "Content Creation",
    href: "/content-creation",
    icon: Image,
  },
  {
    title: "Scheduling",
    href: "/scheduling",
    icon: Calendar,
  },
  {
    title: "Engagement",
    href: "/engagement",
    icon: MessageSquare,
  },
  {
    title: "Analytics",
    href: "/analytics",
    icon: BarChart,
  },
  {
    title: "Security",
    href: "/security",
    icon: Lock,
  },
  {
    title: "Subscription",
    href: "/subscription",
    icon: CreditCard,
  },
  {
    title: "AI Datasets",
    href: "/ai-datasets",
    icon: Database,
  },
  {
    title: "Inspiration Gallery",
    href: "/inspiration-gallery",
    icon: Lightbulb,
  },
  {
    title: "Blog",
    href: "/blog",
    icon: BookOpen,
    public: true,
  },
  {
    title: "Settings",
    href: "/settings",
    icon: Settings,
  },
];

export function Sidebar() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();

  return (
    <aside className="w-64 bg-white shadow-md hidden md:flex flex-col h-screen">
      <div className="p-4 border-b">
        <div className="flex items-center space-x-2">
          <svg className="h-6 w-6 text-[#E1306C]" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M17.5 6.5H17.51M7 2H17C19.7614 2 22 4.23858 22 7V17C22 19.7614 19.7614 22 17 22H7C4.23858 22 2 19.7614 2 17V7C2 4.23858 4.23858 2 7 2ZM16 11.37C16.1234 12.2022 15.9812 13.0522 15.5937 13.799C15.2062 14.5458 14.5931 15.1514 13.8416 15.5297C13.0901 15.9079 12.2384 16.0396 11.4077 15.9059C10.5771 15.7723 9.80971 15.3801 9.21479 14.7852C8.61987 14.1902 8.22768 13.4229 8.09402 12.5922C7.96035 11.7616 8.09202 10.9099 8.47028 10.1584C8.84854 9.40685 9.45414 8.79374 10.2009 8.40624C10.9477 8.01874 11.7977 7.87659 12.63 8C13.4789 8.12588 14.2648 8.52146 14.8717 9.12831C15.4785 9.73515 15.8741 10.5211 16 11.37Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <h1 className="font-bold text-lg">Instagram AI Agent</h1>
        </div>
      </div>
      
      <nav className="p-2 flex-1 overflow-y-auto">
        <ul>
          {navItems.map((item) => (
            <li key={item.href} className="mb-1">
              <Link href={item.href}>
                <a
                  className={cn(
                    "flex items-center px-4 py-2 rounded-lg transition-colors",
                    location === item.href
                      ? "bg-[#0095F6] bg-opacity-10 text-[#0095F6] font-medium"
                      : "hover:bg-[#F5F5F5] text-[#262626]"
                  )}
                >
                  <item.icon className="mr-3 h-5 w-5" />
                  <span>{item.title}</span>
                </a>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
      
      <div className="px-4 py-2 border-t">
        <div className="flex items-center space-x-2 mb-4">
          <div className="w-8 h-8 rounded-full bg-[#0095F6] text-white flex items-center justify-center">
            <span className="text-xs font-bold">
              {user?.username?.[0]?.toUpperCase() || 'U'}
            </span>
          </div>
          <div>
            <p className="text-sm font-medium">{user?.username || 'User'}</p>
            <p className="text-xs text-gray-500">{user?.instagramUsername || 'Not connected'}</p>
          </div>
        </div>
        <Button 
          variant="outline" 
          size="sm" 
          className="w-full" 
          onClick={() => logoutMutation.mutate()}
          disabled={logoutMutation.isPending}
        >
          {logoutMutation.isPending ? "Logging out..." : "Logout"}
        </Button>
      </div>
    </aside>
  );
}
