import { ReactNode } from "react";
import { useLocation } from "wouter";
import { Sidebar } from "./sidebar";
import { MobileNav } from "./mobile-nav";
import { Header } from "./header";

interface MainLayoutProps {
  children: ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  const [location] = useLocation();
  
  // Get page title based on current location
  const getTitle = () => {
    switch (location) {
      case "/":
        return "Dashboard";
      case "/content-creation":
        return "Content Creation";
      case "/scheduling":
        return "Scheduling";
      case "/engagement":
        return "Engagement";
      case "/analytics":
        return "Analytics";
      case "/security":
        return "Security";
      case "/settings":
        return "Settings";
      default:
        return "Dashboard";
    }
  };
  
  return (
    <div className="flex h-screen overflow-hidden bg-[#FAFAFA]">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title={getTitle()} />
        
        <div className="flex-1 overflow-y-auto pb-16 md:pb-0">
          {children}
        </div>
        
        <MobileNav />
      </div>
    </div>
  );
}
