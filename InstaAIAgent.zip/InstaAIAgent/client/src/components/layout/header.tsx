import { useState } from "react";
import { useLocation } from "wouter";
import { Bell, Menu } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Sidebar } from "./sidebar";

interface HeaderProps {
  title: string;
}

export function Header({ title }: HeaderProps) {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [notificationsOpen, setNotificationsOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm">
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center md:hidden">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="mr-2">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0">
              <Sidebar />
            </SheetContent>
          </Sheet>
          <h1 className="font-bold">{title}</h1>
        </div>
        
        <div className="hidden md:block">
          <h1 className="text-xl font-bold">{title}</h1>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Button 
              variant="ghost" 
              size="icon" 
              className="text-gray-500"
              onClick={() => setNotificationsOpen(!notificationsOpen)}
            >
              <Bell className="h-5 w-5" />
              <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-[#DC3545]"></span>
            </Button>
          </div>
          
          <div className="relative md:hidden">
            <Button variant="ghost" size="icon">
              <div className="w-8 h-8 rounded-full bg-[#0095F6] text-white flex items-center justify-center">
                <span className="text-xs font-bold">
                  {user?.username?.[0]?.toUpperCase() || 'U'}
                </span>
              </div>
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
