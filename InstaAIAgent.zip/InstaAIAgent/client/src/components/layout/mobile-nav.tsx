import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  Image,
  Calendar,
  MessageSquare,
  BookOpen,
  MoreHorizontal,
  Database,
  Lightbulb,
} from "lucide-react";

export function MobileNav() {
  const [location] = useLocation();
  
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t md:hidden z-10">
      <div className="flex justify-around">
        <Link href="/">
          <a className={`p-4 ${location === "/" ? "text-[#0095F6]" : "text-gray-500"}`}>
            <LayoutDashboard className="mx-auto text-xl" />
          </a>
        </Link>
        <Link href="/content-creation">
          <a className={`p-4 ${location === "/content-creation" ? "text-[#0095F6]" : "text-gray-500"}`}>
            <Image className="mx-auto text-xl" />
          </a>
        </Link>
        <Link href="/scheduling">
          <a className={`p-4 ${location === "/scheduling" ? "text-[#0095F6]" : "text-gray-500"}`}>
            <Calendar className="mx-auto text-xl" />
          </a>
        </Link>
        <Link href="/ai-datasets">
          <a className={`p-4 ${location === "/ai-datasets" ? "text-[#0095F6]" : "text-gray-500"}`}>
            <Database className="mx-auto text-xl" />
          </a>
        </Link>
        <Link href="/inspiration-gallery">
          <a className={`p-4 ${location === "/inspiration-gallery" ? "text-[#0095F6]" : "text-gray-500"}`}>
            <Lightbulb className="mx-auto text-xl" />
          </a>
        </Link>
        <Link href="/blog">
          <a className={`p-4 ${location.startsWith("/blog") ? "text-[#0095F6]" : "text-gray-500"}`}>
            <BookOpen className="mx-auto text-xl" />
          </a>
        </Link>
        <Link href="/settings">
          <a className={`p-4 ${location === "/settings" ? "text-[#0095F6]" : "text-gray-500"}`}>
            <MoreHorizontal className="mx-auto text-xl" />
          </a>
        </Link>
      </div>
    </div>
  );
}
