import { useEffect, useState } from 'react';
import { 
  useStripe, 
  useElements, 
  PaymentElement,
  AddressElement
} from '@stripe/react-stripe-js';
import { Elements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';

// Initialize Stripe outside component to avoid recreation on each render
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

interface CheckoutFormProps {
  planId: number;
  planName: string;
  planPrice: number;
  returnUrl: string;
}

// Inner form component using Stripe Elements
function CheckoutForm({ planId, planName, planPrice, returnUrl }: CheckoutFormProps) {
  const stripe = useStripe();
  const elements = useElements();
  const [isLoading, setIsLoading] = useState(false);
  const [paymentError, setPaymentError] = useState<string | null>(null);
  const { toast } = useToast();

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsLoading(true);
    setPaymentError(null);

    try {
      // Confirm payment
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          // After payment completion, redirect to return URL with success
          return_url: `${returnUrl}?success=true&plan=${planId}`,
        },
      });

      // Handle payment confirmation error
      if (error) {
        setPaymentError(error.message || 'An unexpected error occurred.');
        toast({
          title: 'Payment failed',
          description: error.message || 'An unexpected error occurred with your payment.',
          variant: 'destructive',
        });
      }
    } catch (err: any) {
      setPaymentError(err.message || 'An unexpected error occurred.');
      toast({
        title: 'Payment system error',
        description: err.message || 'The payment system encountered an error. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div className="space-y-4">
        <CardHeader>
          <CardTitle>{planName} Subscription</CardTitle>
          <CardDescription>
            Subscribe to our {planName} plan with secure payment processing.
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Payment details input */}
          <div className="space-y-2">
            <h3 className="text-sm font-medium">Payment Information</h3>
            <PaymentElement />
          </div>

          {/* Billing address input */}
          <div className="space-y-2">
            <h3 className="text-sm font-medium">Billing Address</h3>
            <AddressElement options={{ mode: 'billing' }} />
          </div>
        </CardContent>

        <CardFooter className="flex flex-col space-y-4">
          {/* Error message */}
          {paymentError && (
            <div className="text-sm font-medium text-destructive">{paymentError}</div>
          )}

          {/* Submit button */}
          <Button 
            type="submit" 
            disabled={!stripe || isLoading} 
            className="w-full"
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Processing...
              </>
            ) : (
              `Pay ${new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: 'USD'
              }).format(planPrice)}`
            )}
          </Button>
        </CardFooter>
      </div>
    </form>
  );
}

interface StripeCheckoutProps {
  planId: number;
  planName: string;
  planPrice: number;
  returnUrl: string;
}

// Main checkout component that sets up Stripe Elements context
export function StripeCheckout({ planId, planName, planPrice, returnUrl }: StripeCheckoutProps) {
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    // Create payment intent when component mounts
    const createPaymentIntent = async () => {
      try {
        setIsLoading(true);
        const response = await apiRequest('POST', '/api/subscription/create-payment-intent', {
          planId
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw new Error(data.message || 'Failed to create payment intent');
        }
        
        setClientSecret(data.clientSecret);
      } catch (err: any) {
        setError(err.message || 'Failed to initialize payment');
        toast({
          title: 'Payment setup failed',
          description: err.message || 'We couldn\'t set up the payment process. Please try again.',
          variant: 'destructive',
        });
      } finally {
        setIsLoading(false);
      }
    };

    createPaymentIntent();
  }, [planId, toast]);

  // Show loading state
  if (isLoading) {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardContent className="pt-6">
          <div className="flex flex-col items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
            <p className="text-sm text-muted-foreground">Setting up payment...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Show error state
  if (error || !clientSecret) {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardContent className="pt-6">
          <div className="flex flex-col items-center justify-center py-8">
            <div className="rounded-full p-3 bg-destructive/10 text-destructive mb-4">
              <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6"
              >
                <path
                  d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>
            <h3 className="text-lg font-medium mb-2">Payment Setup Failed</h3>
            <p className="text-sm text-muted-foreground text-center mb-4">{error || 'Could not initialize payment'}</p>
            <Button 
              variant="outline" 
              onClick={() => window.location.reload()}
            >
              Try Again
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Render Stripe Elements form with the obtained client secret
  return (
    <Card className="w-full max-w-md mx-auto">
      <Elements stripe={stripePromise} options={{ clientSecret }}>
        <CheckoutForm
          planId={planId}
          planName={planName}
          planPrice={planPrice}
          returnUrl={returnUrl}
        />
      </Elements>
    </Card>
  );
}