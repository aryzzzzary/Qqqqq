import { useState, useEffect } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { AISuggestionTooltip } from "@/components/ui/ai-suggestion-tooltip";
import { useAiSuggestions } from "@/hooks/use-ai-suggestions";

interface ContentEditorFieldProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  multiline?: boolean;
  contentType?: string;
  className?: string;
  disabled?: boolean;
  minLength?: number;
}

export function ContentEditorField({
  label,
  value,
  onChange,
  placeholder,
  multiline = false,
  contentType = "general",
  className = "",
  disabled = false,
  minLength = 0,
}: ContentEditorFieldProps) {
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const { getSuggestions, isLoading } = useAiSuggestions();

  // Debounce content changes to avoid too many API calls
  useEffect(() => {
    if (!value || value.length < minLength) {
      setSuggestions([]);
      return;
    }

    const timer = setTimeout(async () => {
      if (value.length >= minLength) {
        try {
          const result = await getSuggestions({
            context: value,
            contentType,
            count: 3
          });
          
          if (result.suggestions?.length) {
            setSuggestions(result.suggestions);
          }
        } catch (error) {
          console.error("Failed to get suggestions:", error);
        }
      }
    }, 1000); // Wait 1 second after typing stops

    return () => clearTimeout(timer);
  }, [value, contentType, getSuggestions, minLength]);

  const handleSelectSuggestion = (suggestion: string) => {
    onChange(suggestion);
  };

  return (
    <div className={`space-y-2 ${className}`}>
      <div className="flex justify-between">
        <label className="text-sm font-medium text-gray-700">{label}</label>
        <span className="text-xs text-gray-500">
          {value.length} characters
        </span>
      </div>
      
      <AISuggestionTooltip 
        suggestions={suggestions} 
        onSelectSuggestion={handleSelectSuggestion}
        isLoading={isLoading}
      >
        {multiline ? (
          <Textarea
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder}
            disabled={disabled}
            className="min-h-[100px] w-full"
          />
        ) : (
          <Input
            type="text"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder}
            disabled={disabled}
            className="w-full"
          />
        )}
      </AISuggestionTooltip>
    </div>
  );
}