import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Post, InsertPost } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Calendar as CalendarIcon, PlusIcon, Pencil, Trash2 } from "lucide-react";
import { format } from "date-fns";

import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { cn } from "@/lib/utils";

const formSchema = z.object({
  caption: z.string().min(1, "Caption is required"),
  contentType: z.string(),
  mediaUrl: z.string().optional(),
  scheduledAt: z.date().optional(),
  status: z.string().default("draft"),
});

type FormValues = z.infer<typeof formSchema>;

export default function Scheduling() {
  const { toast } = useToast();
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [postToDelete, setPostToDelete] = useState<number | null>(null);
  const [openNewPostDialog, setOpenNewPostDialog] = useState(false);
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      caption: "",
      contentType: "image",
      mediaUrl: "",
      status: "draft",
    },
  });
  
  // Query for all scheduled posts
  const { data: posts, isLoading } = useQuery<Post[]>({
    queryKey: ["/api/posts"],
  });
  
  // Create post mutation
  const createPostMutation = useMutation({
    mutationFn: async (data: InsertPost) => {
      const res = await apiRequest("POST", "/api/posts", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      toast({
        title: "Post Created",
        description: "Your post has been scheduled successfully",
      });
      setOpenNewPostDialog(false);
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Failed to create post",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Delete post mutation
  const deletePostMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/posts/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      toast({
        title: "Post deleted",
        description: "The post has been removed from your schedule",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to delete post",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Publish post mutation
  const publishPostMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("POST", `/api/posts/${id}/publish`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      toast({
        title: "Post Published",
        description: "Your post has been published to Instagram",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to publish post",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (values: FormValues) => {
    createPostMutation.mutate({
      ...values,
      userId: 1, // This will be overridden on the server with the authenticated user's ID
      status: values.scheduledAt ? "ready" : "draft",
    });
  };
  
  const handleDelete = (id: number) => {
    setPostToDelete(id);
  };
  
  const confirmDelete = () => {
    if (postToDelete) {
      deletePostMutation.mutate(postToDelete);
      setPostToDelete(null);
    }
  };
  
  const handlePublish = (id: number) => {
    publishPostMutation.mutate(id);
  };
  
  const getPostStatusBadge = (status: string) => {
    switch (status) {
      case "ready":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Ready</Badge>;
      case "draft":
        return <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100">Draft</Badge>;
      case "ai_generated":
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">AI Generated</Badge>;
      case "posted":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Posted</Badge>;
      case "failed":
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Failed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };
  
  const getPostTypeBadge = (contentType: string) => {
    switch (contentType) {
      case "image":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Image</Badge>;
      case "video":
        return <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-100">Video</Badge>;
      case "carousel":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Carousel</Badge>;
      default:
        return <Badge variant="outline">{contentType}</Badge>;
    }
  };
  
  const formatScheduleDate = (date: string | Date | null) => {
    if (!date) return "Not scheduled";
    
    const scheduleDate = new Date(date);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    if (scheduleDate.toDateString() === today.toDateString()) {
      return `Today, ${scheduleDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    } else if (scheduleDate.toDateString() === tomorrow.toDateString()) {
      return `Tomorrow, ${scheduleDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    } else {
      return scheduleDate.toLocaleDateString([], { 
        month: 'short', 
        day: 'numeric', 
        hour: '2-digit', 
        minute: '2-digit' 
      });
    }
  };
  
  // Filter posts by status
  const getDraftPosts = () => posts?.filter(post => post.status === "draft") || [];
  const getScheduledPosts = () => posts?.filter(post => post.status === "ready" || post.status === "ai_generated") || [];
  const getPostedPosts = () => posts?.filter(post => post.status === "posted") || [];
  
  // Get posts scheduled for the selected date
  const getPostsForSelectedDate = () => {
    if (!date || !posts) return [];
    
    return posts.filter(post => {
      if (!post.scheduledAt) return false;
      const postDate = new Date(post.scheduledAt);
      return postDate.toDateString() === date.toDateString();
    });
  };
  
  const postsForSelectedDate = getPostsForSelectedDate();
  
  return (
    <main className="p-4 md:p-6">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">Scheduling</h1>
          <p className="text-gray-500 mt-1">Schedule and manage your Instagram posts</p>
        </div>
        <Dialog open={openNewPostDialog} onOpenChange={setOpenNewPostDialog}>
          <DialogTrigger asChild>
            <Button className="mt-4 md:mt-0 bg-[#0095F6] hover:bg-[#0095F6]/90">
              <PlusIcon className="mr-2 h-4 w-4" /> New Post
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[525px]">
            <DialogHeader>
              <DialogTitle>Create New Post</DialogTitle>
              <DialogDescription>
                Create a new post to schedule for your Instagram account
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="contentType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Content Type</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select content type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="image">Image</SelectItem>
                          <SelectItem value="video">Video</SelectItem>
                          <SelectItem value="carousel">Carousel</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="mediaUrl"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Media URL</FormLabel>
                      <FormControl>
                        <Input placeholder="https://example.com/image.jpg" {...field} />
                      </FormControl>
                      <FormDescription>
                        Enter the URL of your media or upload a file
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="caption"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Caption</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Write your caption here..." 
                          {...field} 
                          rows={4}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="scheduledAt"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Schedule Date</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              className={cn(
                                "w-full pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP HH:mm")
                              ) : (
                                <span>Pick a date and time</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            initialFocus
                          />
                          <div className="p-3 border-t border-border">
                            <Input
                              type="time"
                              onChange={(e) => {
                                const date = field.value || new Date();
                                const [hours, minutes] = e.target.value.split(":");
                                date.setHours(parseInt(hours));
                                date.setMinutes(parseInt(minutes));
                                field.onChange(date);
                              }}
                              defaultValue={field.value ? 
                                `${field.value.getHours().toString().padStart(2, '0')}:${field.value.getMinutes().toString().padStart(2, '0')}` : 
                                undefined
                              }
                            />
                          </div>
                        </PopoverContent>
                      </Popover>
                      <FormDescription>
                        Select when you want to publish this post
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <DialogFooter>
                  <Button 
                    type="submit" 
                    disabled={createPostMutation.isPending}
                    className="bg-[#0095F6] hover:bg-[#0095F6]/90"
                  >
                    {createPostMutation.isPending ? "Creating..." : "Create Post"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <Tabs defaultValue="scheduled" className="space-y-4">
            <TabsList>
              <TabsTrigger value="scheduled">Scheduled</TabsTrigger>
              <TabsTrigger value="drafts">Drafts</TabsTrigger>
              <TabsTrigger value="published">Published</TabsTrigger>
            </TabsList>
            
            <TabsContent value="scheduled" className="space-y-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle>Scheduled Posts</CardTitle>
                  <CardDescription>
                    Posts scheduled to be published automatically
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="space-y-2">
                      {[1, 2, 3].map((i) => (
                        <Skeleton key={i} className="h-20 w-full" />
                      ))}
                    </div>
                  ) : getScheduledPosts().length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Content</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Schedule</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {getScheduledPosts().map((post) => (
                          <TableRow key={post.id}>
                            <TableCell>
                              <div className="flex items-center">
                                <div className="h-10 w-10 rounded bg-gray-200 flex-shrink-0">
                                  {post.thumbnailUrl ? (
                                    <img 
                                      src={post.thumbnailUrl} 
                                      alt="Post thumbnail" 
                                      className="h-full w-full object-cover rounded"
                                    />
                                  ) : (
                                    <div className="h-full w-full flex items-center justify-center text-gray-400">
                                      <Calendar className="h-5 w-5" />
                                    </div>
                                  )}
                                </div>
                                <div className="ml-3">
                                  <p className="text-sm font-medium line-clamp-1">
                                    {post.caption}
                                  </p>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>{getPostTypeBadge(post.contentType)}</TableCell>
                            <TableCell>{formatScheduleDate(post.scheduledAt)}</TableCell>
                            <TableCell>{getPostStatusBadge(post.status)}</TableCell>
                            <TableCell>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="sm">
                                    Actions
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => handlePublish(post.id)}>
                                    Publish Now
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handleDelete(post.id)}>
                                    Delete
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <div className="text-center p-8 text-gray-500">
                      <p>No scheduled posts. Create a new post to get started.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="drafts" className="space-y-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle>Draft Posts</CardTitle>
                  <CardDescription>
                    Posts saved as drafts
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="space-y-2">
                      {[1, 2].map((i) => (
                        <Skeleton key={i} className="h-20 w-full" />
                      ))}
                    </div>
                  ) : getDraftPosts().length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Content</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {getDraftPosts().map((post) => (
                          <TableRow key={post.id}>
                            <TableCell>
                              <div className="flex items-center">
                                <div className="h-10 w-10 rounded bg-gray-200 flex-shrink-0">
                                  {post.thumbnailUrl ? (
                                    <img 
                                      src={post.thumbnailUrl} 
                                      alt="Post thumbnail" 
                                      className="h-full w-full object-cover rounded"
                                    />
                                  ) : (
                                    <div className="h-full w-full flex items-center justify-center text-gray-400">
                                      <Calendar className="h-5 w-5" />
                                    </div>
                                  )}
                                </div>
                                <div className="ml-3">
                                  <p className="text-sm font-medium line-clamp-1">
                                    {post.caption}
                                  </p>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>{getPostTypeBadge(post.contentType)}</TableCell>
                            <TableCell>{getPostStatusBadge(post.status)}</TableCell>
                            <TableCell>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="sm">
                                    Actions
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem>
                                    Edit
                                  </DropdownMenuItem>
                                  <DropdownMenuItem>
                                    Schedule
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handlePublish(post.id)}>
                                    Publish Now
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handleDelete(post.id)}>
                                    Delete
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <div className="text-center p-8 text-gray-500">
                      <p>No draft posts found.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="published" className="space-y-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle>Published Posts</CardTitle>
                  <CardDescription>
                    Posts that have been published to Instagram
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="space-y-2">
                      {[1, 2].map((i) => (
                        <Skeleton key={i} className="h-20 w-full" />
                      ))}
                    </div>
                  ) : getPostedPosts().length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Content</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Published</TableHead>
                          <TableHead>Instagram ID</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {getPostedPosts().map((post) => (
                          <TableRow key={post.id}>
                            <TableCell>
                              <div className="flex items-center">
                                <div className="h-10 w-10 rounded bg-gray-200 flex-shrink-0">
                                  {post.thumbnailUrl ? (
                                    <img 
                                      src={post.thumbnailUrl} 
                                      alt="Post thumbnail" 
                                      className="h-full w-full object-cover rounded"
                                    />
                                  ) : (
                                    <div className="h-full w-full flex items-center justify-center text-gray-400">
                                      <Calendar className="h-5 w-5" />
                                    </div>
                                  )}
                                </div>
                                <div className="ml-3">
                                  <p className="text-sm font-medium line-clamp-1">
                                    {post.caption}
                                  </p>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>{getPostTypeBadge(post.contentType)}</TableCell>
                            <TableCell>
                              {post.postedAt ? format(new Date(post.postedAt), "PPP") : "N/A"}
                            </TableCell>
                            <TableCell>
                              {post.instagramPostId || "N/A"}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <div className="text-center p-8 text-gray-500">
                      <p>No published posts found.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
        
        <div>
          <Card className="h-full">
            <CardHeader>
              <CardTitle>Calendar</CardTitle>
              <CardDescription>
                Schedule your posts with the calendar
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Calendar
                mode="single"
                selected={date}
                onSelect={setDate}
                className="rounded-md border mb-4"
              />
              
              <div className="space-y-2">
                <h3 className="text-sm font-medium">Posts on {date ? format(date, "PP") : "selected date"}</h3>
                {postsForSelectedDate.length > 0 ? (
                  postsForSelectedDate.map((post) => (
                    <div key={post.id} className="border rounded-md p-2 flex items-start space-x-2">
                      <div className="h-8 w-8 rounded bg-gray-200 flex-shrink-0">
                        {post.thumbnailUrl ? (
                          <img 
                            src={post.thumbnailUrl} 
                            alt="Post thumbnail" 
                            className="h-full w-full object-cover rounded"
                          />
                        ) : (
                          <div className="h-full w-full flex items-center justify-center text-gray-400">
                            <Calendar className="h-4 w-4" />
                          </div>
                        )}
                      </div>
                      <div>
                        <p className="text-xs line-clamp-1 font-medium">{post.caption}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <span className="text-[10px] text-gray-500">
                            {post.scheduledAt ? 
                              format(new Date(post.scheduledAt), "h:mm a") : 
                              "No time set"
                            }
                          </span>
                          {getPostStatusBadge(post.status)}
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-gray-500">No posts scheduled for this date</p>
                )}
              </div>
              
              <div className="mt-4">
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => setOpenNewPostDialog(true)}
                >
                  <PlusIcon className="h-4 w-4 mr-2" /> Schedule for {date ? format(date, "PP") : "this date"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <AlertDialog open={postToDelete !== null} onOpenChange={(open) => !open && setPostToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Post</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this post? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-red-500 hover:bg-red-600"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </main>
  );
}
