import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { ContentGenerator } from "@/components/dashboard/content-generator";
import { ContentEditorField } from "@/components/content/content-editor-field";

export default function ContentCreation() {
  const [templateName, setTemplateName] = useState("");
  const [templateContent, setTemplateContent] = useState("");
  
  return (
    <main className="p-4 md:p-6">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">Content Creation</h1>
          <p className="text-gray-500 mt-1">Create and generate Instagram-ready content</p>
        </div>
        <Button className="mt-4 md:mt-0 bg-[#0095F6] hover:bg-[#0095F6]/90">
          Create New Post
        </Button>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>AI Content Generator</CardTitle>
            <CardDescription>
              Let AI help you create engaging posts for your Instagram account
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ContentGenerator />
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Content Templates</CardTitle>
            <CardDescription>Use or create templates for consistent brand messaging</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="use">
              <TabsList className="mb-4">
                <TabsTrigger value="use">Use Template</TabsTrigger>
                <TabsTrigger value="create">Create Template</TabsTrigger>
              </TabsList>
              
              <TabsContent value="use">
                <div className="grid gap-4">
                  {[
                    {
                      title: "Product Launch",
                      description: "Announce a new product with compelling call-to-action",
                    },
                    {
                      title: "Testimonial Spotlight",
                      description: "Highlight customer reviews and feedback",
                    },
                    {
                      title: "Behind The Scenes",
                      description: "Show your process and company culture",
                    },
                  ].map((template, index) => (
                    <Card key={index} className="cursor-pointer hover:border-[#0095F6] transition-colors">
                      <CardContent className="p-4">
                        <h3 className="font-medium">{template.title}</h3>
                        <p className="text-sm text-gray-500 mt-1">{template.description}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="create">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Template Name</label>
                    <Input 
                      placeholder="e.g., Weekly Motivation" 
                      value={templateName}
                      onChange={(e) => setTemplateName(e.target.value)}
                    />
                  </div>
                  
                  <ContentEditorField
                    label="Caption Structure"
                    value={templateContent}
                    onChange={setTemplateContent}
                    placeholder="Write your template here, use {variables} for dynamic content"
                    multiline={true}
                    contentType="instagram_template"
                    minLength={20}
                  />
                  
                  <div className="pt-2">
                    <Button disabled={!templateName || !templateContent}>
                      Save Template
                    </Button>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
      
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Content Library</CardTitle>
          <CardDescription>
            Browse and manage your created content
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center p-8 text-gray-500">
            <p>Your content library is empty. Generate or create content to see it here.</p>
          </div>
        </CardContent>
      </Card>
    </main>
  );
}
