import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { InstagramApiStatus } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table";
import { 
  KeyRound, 
  Shield, 
  AlertTriangle, 
  RefreshCw,
  Lock,
  Eye,
  EyeOff,
  Instagram,
  FileText,
  Clock
} from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

const passwordFormSchema = z.object({
  currentPassword: z.string().min(6, "Password must be at least 6 characters"),
  newPassword: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string().min(6, "Password must be at least 6 characters"),
}).refine(data => data.newPassword === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type PasswordFormValues = z.infer<typeof passwordFormSchema>;

export default function Security() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [showPassword, setShowPassword] = useState(false);
  const [passwordDialogOpen, setPasswordDialogOpen] = useState(false);
  
  const passwordForm = useForm<PasswordFormValues>({
    resolver: zodResolver(passwordFormSchema),
    defaultValues: {
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
  });
  
  const { data: apiStatus, isLoading } = useQuery<InstagramApiStatus>({
    queryKey: ["/api/instagram/status"],
  });
  
  const handleRefreshTokens = () => {
    toast({
      title: "Token Refresh",
      description: "In a production app, this would refresh your Instagram API tokens.",
    });
  };
  
  const onPasswordSubmit = (values: PasswordFormValues) => {
    toast({
      title: "Password Updated",
      description: "Your password has been changed successfully",
    });
    setPasswordDialogOpen(false);
    passwordForm.reset();
  };
  
  // Mock access log data
  const accessLogData = [
    { id: 1, ip: "192.168.1.1", location: "New York, US", device: "Chrome on Windows", time: "Today, 10:45 AM", status: "success" },
    { id: 2, ip: "45.67.89.101", location: "San Francisco, US", device: "Safari on macOS", time: "Yesterday, 3:22 PM", status: "success" },
    { id: 3, ip: "112.45.78.90", location: "Beijing, CN", device: "Chrome on Android", time: "Jun 5, 9:15 AM", status: "suspicious" },
    { id: 4, ip: "78.90.123.45", location: "London, UK", device: "Firefox on Windows", time: "Jun 3, 11:30 AM", status: "success" },
    { id: 5, ip: "203.45.67.89", location: "Sydney, AU", device: "Safari on iOS", time: "Jun 1, 5:45 PM", status: "success" },
  ];
  
  if (isLoading) {
    return (
      <main className="p-4 md:p-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
          <Skeleton className="h-10 w-48" />
        </div>
        <div className="grid gap-6">
          <Skeleton className="h-64 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      </main>
    );
  }
  
  return (
    <main className="p-4 md:p-6">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">Security & Credentials</h1>
          <p className="text-gray-500 mt-1">Manage your account security and API credentials</p>
        </div>
        <Button 
          onClick={handleRefreshTokens}
          className="mt-4 md:mt-0 flex items-center"
        >
          <RefreshCw className="mr-2 h-4 w-4" /> Refresh Tokens
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Shield className="h-5 w-5 text-[#0095F6]" />
              <CardTitle>Account Security</CardTitle>
            </div>
            <CardDescription>
              Manage your account security settings
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <div className="text-sm font-medium">Two-Factor Authentication</div>
                <div className="text-sm text-muted-foreground">
                  Add an extra layer of security to your account
                </div>
              </div>
              <Switch defaultChecked />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <div className="text-sm font-medium">Login Notifications</div>
                <div className="text-sm text-muted-foreground">
                  Receive alerts about new login attempts
                </div>
              </div>
              <Switch defaultChecked />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <div className="text-sm font-medium">Suspicious Activity Alerts</div>
                <div className="text-sm text-muted-foreground">
                  Get notified about unusual account activity
                </div>
              </div>
              <Switch defaultChecked />
            </div>
          </CardContent>
          <CardFooter>
            <Dialog open={passwordDialogOpen} onOpenChange={setPasswordDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" className="w-full">
                  <Lock className="mr-2 h-4 w-4" />
                  Change Password
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Change Password</DialogTitle>
                  <DialogDescription>
                    Create a new password for your account
                  </DialogDescription>
                </DialogHeader>
                
                <Form {...passwordForm}>
                  <form onSubmit={passwordForm.handleSubmit(onPasswordSubmit)} className="space-y-4">
                    <FormField
                      control={passwordForm.control}
                      name="currentPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Current Password</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Input 
                                type={showPassword ? "text" : "password"} 
                                {...field} 
                              />
                              <button
                                type="button"
                                className="absolute right-2 top-2.5 text-gray-500"
                                onClick={() => setShowPassword(!showPassword)}
                              >
                                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                              </button>
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={passwordForm.control}
                      name="newPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>New Password</FormLabel>
                          <FormControl>
                            <Input type="password" {...field} />
                          </FormControl>
                          <FormDescription>
                            Password must be at least 6 characters
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={passwordForm.control}
                      name="confirmPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Confirm New Password</FormLabel>
                          <FormControl>
                            <Input type="password" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <DialogFooter>
                      <Button type="submit">Update Password</Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader>
            <div className="flex items-center space-x-2">
              <KeyRound className="h-5 w-5 text-[#0095F6]" />
              <CardTitle>API Credentials</CardTitle>
            </div>
            <CardDescription>
              Manage your Instagram API connection
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <div className="text-sm font-medium">Connection Status</div>
              {apiStatus?.connected ? (
                <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                  Active
                </Badge>
              ) : (
                <Badge className="bg-red-100 text-red-800 hover:bg-red-100">
                  Disconnected
                </Badge>
              )}
            </div>
            
            <div className="flex justify-between items-center">
              <div className="text-sm font-medium">Business Account</div>
              <div className="text-sm">{apiStatus?.businessAccount || "Not connected"}</div>
            </div>
            
            <div className="flex justify-between items-center">
              <div className="text-sm font-medium">Token Expiration</div>
              <div className="text-sm">59 days remaining</div>
            </div>
            
            <div className="flex justify-between items-center">
              <div className="text-sm font-medium">Last Sync</div>
              <div className="text-sm">{apiStatus?.lastSync || "Never"}</div>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col space-y-2">
            <Button 
              variant="outline" 
              className="w-full"
              disabled={!user}
            >
              <Instagram className="mr-2 h-4 w-4" />
              {apiStatus?.connected ? "Reconnect to Instagram" : "Connect to Instagram"}
            </Button>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" className="w-full border-red-200 text-red-500 hover:bg-red-50 hover:text-red-600">
                  Revoke API Access
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Revoke API Access</AlertDialogTitle>
                  <AlertDialogDescription>
                    This will revoke all Instagram API access tokens and your account will no longer be able to post or engage automatically.
                    
                    Are you sure you want to continue?
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction className="bg-red-500 hover:bg-red-600">
                    Yes, Revoke Access
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </CardFooter>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 gap-6 mb-6">
        <Card>
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-[#0095F6]" />
              <CardTitle>Access Log</CardTitle>
            </div>
            <CardDescription>
              Recent account activity and login attempts
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all">
              <TabsList>
                <TabsTrigger value="all">All Activity</TabsTrigger>
                <TabsTrigger value="suspicious">Suspicious Activity</TabsTrigger>
              </TabsList>
              <div className="mt-4">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>IP Address</TableHead>
                      <TableHead>Location</TableHead>
                      <TableHead>Device</TableHead>
                      <TableHead>Time</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {accessLogData
                      .filter(log => 
                        TabsContent === "all" ? true : log.status === "suspicious"
                      )
                      .map((log) => (
                        <TableRow key={log.id}>
                          <TableCell>{log.ip}</TableCell>
                          <TableCell>{log.location}</TableCell>
                          <TableCell>{log.device}</TableCell>
                          <TableCell>{log.time}</TableCell>
                          <TableCell>
                            {log.status === "success" ? (
                              <Badge className="bg-green-100 text-green-800">
                                Success
                              </Badge>
                            ) : (
                              <Badge className="bg-yellow-100 text-yellow-800">
                                Suspicious
                              </Badge>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </div>
            </Tabs>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <div className="flex items-center space-x-2">
            <FileText className="h-5 w-5 text-[#0095F6]" />
            <CardTitle>API Permissions & Scopes</CardTitle>
          </div>
          <CardDescription>
            Manage your Instagram API scopes and permissions
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="border rounded-md p-4">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-medium text-sm">Content Publishing</h3>
                  <Badge className="bg-green-100 text-green-800">
                    Granted
                  </Badge>
                </div>
                <p className="text-sm text-gray-500">
                  Allows posting photos, videos, carousels and stories to Instagram
                </p>
              </div>
              
              <div className="border rounded-md p-4">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-medium text-sm">Comment Moderation</h3>
                  <Badge className="bg-green-100 text-green-800">
                    Granted
                  </Badge>
                </div>
                <p className="text-sm text-gray-500">
                  Allows retrieving, replying to, and moderating comments
                </p>
              </div>
              
              <div className="border rounded-md p-4">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-medium text-sm">Hashtag Search</h3>
                  <Badge className="bg-green-100 text-green-800">
                    Granted
                  </Badge>
                </div>
                <p className="text-sm text-gray-500">
                  Allows discovering content by hashtags for engagement
                </p>
              </div>
              
              <div className="border rounded-md p-4">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-medium text-sm">Insights & Analytics</h3>
                  <Badge className="bg-green-100 text-green-800">
                    Granted
                  </Badge>
                </div>
                <p className="text-sm text-gray-500">
                  Allows retrieving performance metrics for your content
                </p>
              </div>
              
              <div className="border rounded-md p-4">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-medium text-sm">User Profile</h3>
                  <Badge className="bg-green-100 text-green-800">
                    Granted
                  </Badge>
                </div>
                <p className="text-sm text-gray-500">
                  Allows access to profile information and basic metrics
                </p>
              </div>
              
              <div className="border rounded-md p-4">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-medium text-sm">Direct Messages</h3>
                  <Badge className="bg-yellow-100 text-yellow-800">
                    Limited
                  </Badge>
                </div>
                <p className="text-sm text-gray-500">
                  Access to direct messages has restricted availability
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
        <div className="flex">
          <AlertTriangle className="text-yellow-500 h-4 w-4 mt-0.5 mr-2 flex-shrink-0" />
          <div>
            <p className="text-sm text-yellow-700">
              Your API credentials are securely stored and encrypted. Credentials expire in 59 days - we'll remind you when it's time to refresh your tokens.
            </p>
          </div>
        </div>
      </div>
    </main>
  );
}
