import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { EngagementSettings } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { InfoIcon, MessageSquare, ThumbsUp, Users } from "lucide-react";

const limitsFormSchema = z.object({
  dailyCommentLimit: z.number().min(1).max(100),
  dailyLikeLimit: z.number().min(1).max(500),
  dailyFollowLimit: z.number().min(1).max(100),
});

type LimitsFormValues = z.infer<typeof limitsFormSchema>;

const responseFormSchema = z.object({
  positiveTemplate: z.string().min(10, "Template must be at least 10 characters"),
  questionTemplate: z.string().min(10, "Template must be at least 10 characters"),
  negativeTemplate: z.string().min(10, "Template must be at least 10 characters"),
});

type ResponseFormValues = z.infer<typeof responseFormSchema>;

export default function Engagement() {
  const { toast } = useToast();
  const [limitsDialogOpen, setLimitsDialogOpen] = useState(false);
  const [responseDialogOpen, setResponseDialogOpen] = useState(false);
  
  const { data: settings, isLoading } = useQuery<EngagementSettings>({
    queryKey: ["/api/engagement-settings"],
  });
  
  const limitsForm = useForm<LimitsFormValues>({
    resolver: zodResolver(limitsFormSchema),
    defaultValues: {
      dailyCommentLimit: settings?.dailyCommentLimit || 25,
      dailyLikeLimit: settings?.dailyLikeLimit || 100,
      dailyFollowLimit: settings?.dailyFollowLimit || 30,
    },
  });
  
  const responseForm = useForm<ResponseFormValues>({
    resolver: zodResolver(responseFormSchema),
    defaultValues: {
      positiveTemplate: "Thank you so much for your kind words! We really appreciate your support. 💙",
      questionTemplate: "Thanks for reaching out! {answer} Let us know if you have any other questions!",
      negativeTemplate: "We're sorry to hear about your experience. Please DM us so we can make it right.",
    },
  });
  
  const updateSettingsMutation = useMutation({
    mutationFn: async (data: Partial<EngagementSettings>) => {
      const res = await apiRequest("PUT", "/api/engagement-settings", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/engagement-settings"] });
      toast({
        title: "Settings Updated",
        description: "Your engagement settings have been saved",
      });
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: error instanceof Error ? error.message : "Failed to update settings",
        variant: "destructive",
      });
    },
  });
  
  const handleToggleChange = (field: keyof EngagementSettings, checked: boolean) => {
    updateSettingsMutation.mutate({
      [field]: checked,
    });
  };
  
  const onLimitsSubmit = (values: LimitsFormValues) => {
    updateSettingsMutation.mutate(values);
    setLimitsDialogOpen(false);
  };
  
  const onResponseSubmit = (values: ResponseFormValues) => {
    // In a real app, this would update response templates in the database
    toast({
      title: "Templates Updated",
      description: "Your response templates have been saved",
    });
    setResponseDialogOpen(false);
  };
  
  if (isLoading) {
    return (
      <main className="p-4 md:p-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
          <Skeleton className="h-10 w-48" />
        </div>
        <div className="grid gap-6">
          <Skeleton className="h-64 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      </main>
    );
  }
  
  if (!settings) {
    return null;
  }
  
  // For demo purposes - in a real app, this data would come from the API
  const commentsUsage = 0;
  const likesUsage = 43;
  const followsUsage = 12;
  
  // Mock recent activity data
  const recentActivity = [
    { 
      type: "comment", 
      content: "Thanks for sharing this amazing content!", 
      response: "Thank you for your kind words! 💙", 
      user: "@happy_customer", 
      time: "2 hours ago" 
    },
    { 
      type: "like", 
      content: "", 
      user: "@fashion_lover", 
      time: "3 hours ago" 
    },
    { 
      type: "comment", 
      content: "When will this be available?", 
      response: "It will be available next week! Let us know if you have any other questions.", 
      user: "@interested_buyer", 
      time: "5 hours ago" 
    },
    { 
      type: "like", 
      content: "", 
      user: "@style_enthusiast", 
      time: "Yesterday" 
    },
    { 
      type: "like", 
      content: "", 
      user: "@trendsetter", 
      time: "Yesterday" 
    },
  ];
  
  return (
    <main className="p-4 md:p-6">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">Engagement Automation</h1>
          <p className="text-gray-500 mt-1">Configure how your account engages with your audience</p>
        </div>
        <div className="flex items-center mt-4 md:mt-0 space-x-2">
          <span className="text-sm">Automation</span>
          <Switch
            checked={settings.autoComments || settings.autoLikes}
            onCheckedChange={(checked) => {
              updateSettingsMutation.mutate({
                autoComments: checked,
                autoLikes: checked,
              });
            }}
          />
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg flex items-center">
                <MessageSquare className="h-5 w-5 mr-2 text-[#0095F6]" />
                Automated Comments
              </CardTitle>
              <Switch
                checked={settings.autoComments}
                onCheckedChange={(checked) => handleToggleChange('autoComments', checked)}
              />
            </div>
            <CardDescription>
              Automatically respond to comments using AI
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center">
                  <Checkbox
                    id="comment-positive"
                    checked={settings.commentPositiveMentions}
                    onCheckedChange={(checked) => 
                      handleToggleChange('commentPositiveMentions', checked as boolean)
                    }
                    className="mr-2"
                  />
                  <Label htmlFor="comment-positive">Positive mentions</Label>
                </div>
                <div className="flex items-center">
                  <Checkbox
                    id="comment-questions"
                    checked={settings.commentQuestions}
                    onCheckedChange={(checked) => 
                      handleToggleChange('commentQuestions', checked as boolean)
                    }
                    className="mr-2"
                  />
                  <Label htmlFor="comment-questions">Product questions</Label>
                </div>
                <div className="flex items-center">
                  <Checkbox
                    id="comment-negative"
                    checked={settings.commentNegativeFeedback}
                    onCheckedChange={(checked) => 
                      handleToggleChange('commentNegativeFeedback', checked as boolean)
                    }
                    className="mr-2"
                  />
                  <Label htmlFor="comment-negative">Negative feedback</Label>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Daily usage</span>
                  <span>{commentsUsage}/{settings.dailyCommentLimit}</span>
                </div>
                <Progress 
                  value={(commentsUsage / settings.dailyCommentLimit) * 100} 
                  className="h-2"
                />
              </div>
              
              <Dialog open={responseDialogOpen} onOpenChange={setResponseDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" className="w-full">
                    Edit Response Templates
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[525px]">
                  <DialogHeader>
                    <DialogTitle>Response Templates</DialogTitle>
                    <DialogDescription>
                      Customize the templates used for automatic responses
                    </DialogDescription>
                  </DialogHeader>
                  
                  <Form {...responseForm}>
                    <form onSubmit={responseForm.handleSubmit(onResponseSubmit)} className="space-y-4">
                      <FormField
                        control={responseForm.control}
                        name="positiveTemplate"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Positive Mentions Template</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormDescription>
                              Used when responding to positive comments and mentions
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={responseForm.control}
                        name="questionTemplate"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Product Questions Template</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormDescription>
                              Use {"{answer}"} as placeholder for AI-generated answers
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={responseForm.control}
                        name="negativeTemplate"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Negative Feedback Template</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormDescription>
                              Used when responding to negative comments
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <DialogFooter>
                        <Button type="submit">Save Changes</Button>
                      </DialogFooter>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg flex items-center">
                <ThumbsUp className="h-5 w-5 mr-2 text-[#0095F6]" />
                Automated Likes
              </CardTitle>
              <Switch
                checked={settings.autoLikes}
                onCheckedChange={(checked) => handleToggleChange('autoLikes', checked)}
              />
            </div>
            <CardDescription>
              Automatically like content from specific sources
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center">
                  <Checkbox
                    id="like-followers"
                    checked={settings.likeFollowerPosts}
                    onCheckedChange={(checked) =>
                      handleToggleChange('likeFollowerPosts', checked as boolean)
                    }
                    className="mr-2"
                  />
                  <Label htmlFor="like-followers">Posts from followers</Label>
                </div>
                <div className="flex items-center">
                  <Checkbox
                    id="like-hashtags"
                    checked={settings.likeHashtags}
                    onCheckedChange={(checked) =>
                      handleToggleChange('likeHashtags', checked as boolean)
                    }
                    className="mr-2"
                  />
                  <Label htmlFor="like-hashtags">Tracked hashtags</Label>
                </div>
                <div className="flex items-center">
                  <Checkbox
                    id="like-mentions"
                    checked={settings.likeBrandMentions}
                    onCheckedChange={(checked) =>
                      handleToggleChange('likeBrandMentions', checked as boolean)
                    }
                    className="mr-2"
                  />
                  <Label htmlFor="like-mentions">Brand mentions</Label>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Daily usage</span>
                  <span>{likesUsage}/{settings.dailyLikeLimit}</span>
                </div>
                <Progress 
                  value={(likesUsage / settings.dailyLikeLimit) * 100} 
                  className="h-2"
                />
              </div>
              
              <Button variant="outline" size="sm" className="w-full">
                Configure Hashtags
              </Button>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg flex items-center">
                <Users className="h-5 w-5 mr-2 text-[#0095F6]" />
                Follow Management
              </CardTitle>
            </div>
            <CardDescription>
              Manage automated follow/unfollow activities
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-3 rounded-md bg-yellow-50 border border-yellow-200">
                <div className="flex items-start">
                  <InfoIcon className="h-4 w-4 text-yellow-500 mt-0.5 mr-2" />
                  <p className="text-xs text-yellow-700">
                    Follow/unfollow automation requires higher API access levels and carries a higher risk of Instagram restrictions. Use with caution.
                  </p>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Daily follows</span>
                  <span>{followsUsage}/{settings.dailyFollowLimit}</span>
                </div>
                <Progress 
                  value={(followsUsage / settings.dailyFollowLimit) * 100} 
                  className="h-2"
                />
              </div>
              
              <Dialog open={limitsDialogOpen} onOpenChange={setLimitsDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" className="w-full">
                    Adjust Engagement Limits
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px]">
                  <DialogHeader>
                    <DialogTitle>Engagement Limits</DialogTitle>
                    <DialogDescription>
                      Set safe limits to avoid Instagram restrictions
                    </DialogDescription>
                  </DialogHeader>
                  
                  <Form {...limitsForm}>
                    <form onSubmit={limitsForm.handleSubmit(onLimitsSubmit)} className="space-y-4">
                      <FormField
                        control={limitsForm.control}
                        name="dailyCommentLimit"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Daily Comment Limit</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                min={1} 
                                max={100} 
                                {...field}
                                onChange={(e) => field.onChange(parseInt(e.target.value))}
                              />
                            </FormControl>
                            <FormDescription>
                              Recommended: 25-50 comments per day
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={limitsForm.control}
                        name="dailyLikeLimit"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Daily Like Limit</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                min={1} 
                                max={500} 
                                {...field}
                                onChange={(e) => field.onChange(parseInt(e.target.value))}
                              />
                            </FormControl>
                            <FormDescription>
                              Recommended: 100-300 likes per day
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={limitsForm.control}
                        name="dailyFollowLimit"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Daily Follow Limit</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                min={1} 
                                max={100} 
                                {...field}
                                onChange={(e) => field.onChange(parseInt(e.target.value))}
                              />
                            </FormControl>
                            <FormDescription>
                              Recommended: 20-30 follows per day
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <DialogFooter>
                        <Button type="submit">Save Limits</Button>
                      </DialogFooter>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Recent Engagement Activity</CardTitle>
            <CardDescription>
              Recent automated interactions with your audience
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all" className="space-y-4">
              <TabsList>
                <TabsTrigger value="all">All Activity</TabsTrigger>
                <TabsTrigger value="comments">Comments</TabsTrigger>
                <TabsTrigger value="likes">Likes</TabsTrigger>
                <TabsTrigger value="follows">Follows</TabsTrigger>
              </TabsList>
              
              <TabsContent value="all">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Type</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Content</TableHead>
                      <TableHead>Response</TableHead>
                      <TableHead>Time</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recentActivity.map((activity, index) => (
                      <TableRow key={index}>
                        <TableCell>
                          {activity.type === "comment" ? (
                            <div className="flex items-center">
                              <MessageSquare className="h-4 w-4 mr-2 text-[#0095F6]" />
                              <span>Comment</span>
                            </div>
                          ) : (
                            <div className="flex items-center">
                              <ThumbsUp className="h-4 w-4 mr-2 text-[#0095F6]" />
                              <span>Like</span>
                            </div>
                          )}
                        </TableCell>
                        <TableCell>{activity.user}</TableCell>
                        <TableCell className="max-w-xs truncate">
                          {activity.content || "—"}
                        </TableCell>
                        <TableCell className="max-w-xs truncate">
                          {activity.response || "—"}
                        </TableCell>
                        <TableCell>{activity.time}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TabsContent>
              
              <TabsContent value="comments">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>User</TableHead>
                      <TableHead>Comment</TableHead>
                      <TableHead>Response</TableHead>
                      <TableHead>Time</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recentActivity
                      .filter(activity => activity.type === "comment")
                      .map((activity, index) => (
                        <TableRow key={index}>
                          <TableCell>{activity.user}</TableCell>
                          <TableCell className="max-w-xs truncate">{activity.content}</TableCell>
                          <TableCell className="max-w-xs truncate">{activity.response}</TableCell>
                          <TableCell>{activity.time}</TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </TabsContent>
              
              <TabsContent value="likes">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>User</TableHead>
                      <TableHead>Post Type</TableHead>
                      <TableHead>Time</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recentActivity
                      .filter(activity => activity.type === "like")
                      .map((activity, index) => (
                        <TableRow key={index}>
                          <TableCell>{activity.user}</TableCell>
                          <TableCell>Photo</TableCell>
                          <TableCell>{activity.time}</TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </TabsContent>
              
              <TabsContent value="follows">
                <div className="text-center p-8 text-gray-500">
                  <p>No follow activity recorded in this period.</p>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
      
      <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
        <div className="flex">
          <InfoIcon className="text-yellow-500 h-4 w-4 mt-0.5 mr-2 flex-shrink-0" />
          <div>
            <p className="text-sm text-yellow-700">
              Instagram's API rate limiting and engagement restrictions change frequently. Always keep your engagement levels conservative to avoid account restrictions or flags.
            </p>
          </div>
        </div>
      </div>
    </main>
  );
}
