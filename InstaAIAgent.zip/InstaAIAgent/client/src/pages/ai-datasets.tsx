import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent
} from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { AlertCircle, ChevronRight, Search, Database, Tag } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface DatasetInfo {
  id: string;
  name: string;
  description: string;
  tags: string[];
  downloads: number;
  likes: number;
}

function SearchTab() {
  const [searchQuery, setSearchQuery] = useState("");
  const [searching, setSearching] = useState(false);
  const { toast } = useToast();

  const {
    data: searchResults,
    isLoading,
    refetch,
    isError,
    error
  } = useQuery<DatasetInfo[]>({
    queryKey: ["/api/huggingface/datasets/search", searchQuery],
    queryFn: async () => {
      if (!searchQuery || !searching) return [];
      
      const response = await apiRequest(
        "GET", 
        `/api/huggingface/datasets/search?query=${encodeURIComponent(searchQuery)}&limit=10`
      );
      return await response.json();
    },
    enabled: false
  });

  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      toast({
        title: "Search query required",
        description: "Please enter a search term",
        variant: "destructive"
      });
      return;
    }
    
    setSearching(true);
    refetch();
  };

  const getSampleData = async (datasetId: string) => {
    try {
      const response = await apiRequest(
        "GET",
        `/api/huggingface/datasets/${datasetId}/samples?count=5`
      );
      
      const samples = await response.json();
      
      toast({
        title: `Samples from ${datasetId}`,
        description: (
          <div className="mt-2 max-h-[300px] overflow-auto">
            <pre className="text-xs whitespace-pre-wrap">{JSON.stringify(samples, null, 2)}</pre>
          </div>
        ),
        duration: 10000
      });
    } catch (err) {
      console.error("Error fetching samples:", err);
      toast({
        title: "Error fetching samples",
        description: "Could not retrieve dataset samples",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <div className="flex-1">
          <Input
            placeholder="Search datasets (e.g., 'image generation')"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
          />
        </div>
        <Button onClick={handleSearch} disabled={isLoading}>
          <Search className="h-4 w-4 mr-2" />
          Search
        </Button>
      </div>

      {isError && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>
            {(error as Error)?.message || "Failed to search datasets"}
          </AlertDescription>
        </Alert>
      )}

      {searching && isLoading && (
        <div className="py-8 text-center">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Searching datasets...</p>
        </div>
      )}

      {searchResults && searchResults.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Search Results</h3>
          <div className="grid gap-4 md:grid-cols-2">
            {searchResults.map((dataset) => (
              <Card key={dataset.id} className="overflow-hidden">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">{dataset.name}</CardTitle>
                  <CardDescription className="text-xs truncate">{dataset.id}</CardDescription>
                </CardHeader>
                <CardContent className="pb-2">
                  <p className="text-sm line-clamp-2">{dataset.description || "No description available"}</p>
                  <div className="mt-2 flex flex-wrap gap-1">
                    {dataset.tags.slice(0, 3).map((tag) => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                    {dataset.tags.length > 3 && (
                      <Badge variant="outline" className="text-xs">
                        +{dataset.tags.length - 3} more
                      </Badge>
                    )}
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between items-center pt-0">
                  <div className="flex items-center gap-4 text-xs text-muted-foreground">
                    <span>{dataset.downloads.toLocaleString()} downloads</span>
                    <span>{dataset.likes.toLocaleString()} likes</span>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => getSampleData(dataset.id)}
                  >
                    View Samples
                    <ChevronRight className="h-4 w-4 ml-1" />
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      )}

      {searching && searchResults && searchResults.length === 0 && !isLoading && (
        <div className="py-8 text-center">
          <p className="text-muted-foreground">No datasets found matching your query</p>
        </div>
      )}
    </div>
  );
}

function EasyNegativeTab() {
  const { toast } = useToast();
  const [sampleCount, setSampleCount] = useState(10);

  const { data: datasetInfo, isLoading: isLoadingInfo } = useQuery<DatasetInfo>({
    queryKey: ["/api/huggingface/datasets/easynegative"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/huggingface/datasets/easynegative");
      return await response.json();
    }
  });

  const { 
    data: samples, 
    isLoading: isLoadingSamples,
    refetch: refetchSamples
  } = useQuery<string[]>({
    queryKey: ["/api/huggingface/datasets/easynegative/samples", sampleCount],
    queryFn: async () => {
      const response = await apiRequest(
        "GET", 
        `/api/huggingface/datasets/easynegative/samples?count=${sampleCount}`
      );
      return await response.json();
    }
  });

  const handleRefreshSamples = () => {
    refetchSamples();
    toast({
      title: "Refreshing samples",
      description: "Getting new samples from the EasyNegative dataset"
    });
  };

  return (
    <div className="space-y-4">
      {isLoadingInfo ? (
        <div className="py-8 text-center">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading dataset info...</p>
        </div>
      ) : (
        datasetInfo && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                {datasetInfo.name}
              </CardTitle>
              <CardDescription>{datasetInfo.id}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>{datasetInfo.description}</p>
              
              <div>
                <h4 className="text-sm font-medium mb-2">Tags</h4>
                <div className="flex flex-wrap gap-1">
                  {datasetInfo.tags.map((tag) => (
                    <Badge key={tag} className="flex items-center gap-1">
                      <Tag className="h-3 w-3" />
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm">Downloads</Label>
                  <p className="text-xl font-bold">{datasetInfo.downloads.toLocaleString()}</p>
                </div>
                <div>
                  <Label className="text-sm">Likes</Label>
                  <p className="text-xl font-bold">{datasetInfo.likes.toLocaleString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )
      )}

      <div className="bg-card p-4 rounded-lg border">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-medium">EasyNegative Samples</h3>
          <div className="flex items-center gap-2">
            <Input
              type="number"
              value={sampleCount}
              onChange={(e) => setSampleCount(parseInt(e.target.value) || 5)}
              className="w-20"
              min={1}
              max={50}
            />
            <Button onClick={handleRefreshSamples} disabled={isLoadingSamples}>
              Refresh
            </Button>
          </div>
        </div>
        
        <Separator className="my-4" />
        
        {isLoadingSamples ? (
          <div className="py-8 text-center">
            <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto"></div>
            <p className="mt-2 text-muted-foreground">Loading samples...</p>
          </div>
        ) : (
          samples && (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-16">#</TableHead>
                  <TableHead>Negative Prompt</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {samples.map((sample, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-medium">{index + 1}</TableCell>
                    <TableCell className="font-mono text-xs">{sample}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )
        )}
        
        {samples && samples.length === 0 && (
          <div className="py-8 text-center">
            <p className="text-muted-foreground">No samples available</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default function AIDatasetsPage() {
  return (
    <div className="container max-w-6xl py-8">
      <div className="space-y-2 mb-6">
        <h1 className="text-3xl font-bold tracking-tight">AI Datasets</h1>
        <p className="text-muted-foreground">
          Browse, search, and use datasets from Hugging Face to enhance your AI-generated content
        </p>
      </div>

      <Tabs defaultValue="search" className="space-y-4">
        <TabsList>
          <TabsTrigger value="search">Search Datasets</TabsTrigger>
          <TabsTrigger value="easynegative">EasyNegative Dataset</TabsTrigger>
        </TabsList>

        <TabsContent value="search" className="space-y-4">
          <SearchTab />
        </TabsContent>

        <TabsContent value="easynegative" className="space-y-4">
          <EasyNegativeTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}