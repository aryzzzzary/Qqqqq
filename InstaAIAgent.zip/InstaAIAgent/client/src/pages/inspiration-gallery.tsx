import React, { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { InspirationGallery as InspirationGalleryType } from "@shared/schema";

// UI components
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Heart, Share2, Eye, Plus, ImageIcon, Loader2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";

// Create form schema
const createInspirationSchema = z.object({
  prompt: z.string().min(5, "Prompt must be at least 5 characters"),
  style: z.string().optional(),
  category: z.string().optional(),
});

type CreateInspirationForm = z.infer<typeof createInspirationSchema>;

const InspirationGalleryPage: React.FC = () => {
  const { toast } = useToast();
  const [selectedItem, setSelectedItem] = useState<InspirationGalleryType | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState("browse");

  // Fetch inspiration gallery items
  const { data: items, isLoading } = useQuery<InspirationGalleryType[]>({
    queryKey: ['/api/inspiration'],
    refetchOnWindowFocus: false,
  });

  // Form setup for creating new inspiration
  const form = useForm<CreateInspirationForm>({
    resolver: zodResolver(createInspirationSchema),
    defaultValues: {
      prompt: "",
      style: "realistic",
      category: "social-media",
    },
  });

  // Mutation for generating AI inspiration
  const generateMutation = useMutation({
    mutationFn: async (data: CreateInspirationForm) => {
      const response = await apiRequest('POST', '/api/inspiration/generate', data);
      return await response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Image generated successfully!",
        description: "Your AI-generated inspiration has been added to the gallery.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/inspiration'] });
      form.reset();
      setIsGenerating(false);
      setActiveTab("browse");
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to generate image",
        description: error.message,
        variant: "destructive",
      });
      setIsGenerating(false);
    },
  });

  // Interaction mutations
  const interactionMutation = useMutation({
    mutationFn: async ({ itemId, action }: { itemId: number, action: 'like' | 'view' | 'share' }) => {
      const response = await apiRequest('POST', `/api/inspiration/${itemId}/${action}`);
      return await response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/inspiration'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to record interaction",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle form submission for generating AI inspiration
  const onSubmitGenerate = async (data: CreateInspirationForm) => {
    setIsGenerating(true);
    generateMutation.mutate(data);
  };

  // Filter items by category if a category is selected
  const filteredItems = items?.filter(item => 
    !activeCategory || item.category === activeCategory
  );

  // Get unique categories from items
  const categories = items 
    ? [...new Set(items.map(item => item.category))].filter(Boolean) 
    : [];

  // Handle interactions (like, view, share)
  const handleInteraction = (id: number, action: 'like' | 'view' | 'share') => {
    interactionMutation.mutate({ itemId: id, action });
  };

  // Open item detail dialog
  const openItemDetail = (item: InspirationGalleryType) => {
    setSelectedItem(item);
    // Record view
    handleInteraction(item.id, 'view');
  };

  return (
    <div className="container py-8 mx-auto">
      <div className="flex flex-col space-y-6">
        <div className="flex flex-col space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">Inspiration Gallery</h1>
          <p className="text-muted-foreground">
            Discover visual inspiration for your Instagram content and generate AI-powered previews
          </p>
        </div>

        <Tabs defaultValue="browse" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="flex items-center justify-between mb-4">
            <TabsList>
              <TabsTrigger value="browse">Browse Inspiration</TabsTrigger>
              <TabsTrigger value="generate">Generate New</TabsTrigger>
            </TabsList>
            
            {activeTab === "browse" && (
              <Select 
                onValueChange={(value) => setActiveCategory(value === "all" ? null : value)}
                defaultValue="all"
              >
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filter by category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>{
                      category.charAt(0).toUpperCase() + category.slice(1).replace(/-/g, ' ')
                    }</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>

          <TabsContent value="browse" className="mt-0">
            {isLoading ? (
              <div className="flex justify-center items-center h-64">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : filteredItems?.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-64 space-y-4">
                <ImageIcon className="h-16 w-16 text-muted-foreground" />
                <p className="text-xl text-muted-foreground">No inspiration found</p>
                <Button onClick={() => setActiveTab("generate")}>
                  <Plus className="mr-2 h-4 w-4" /> Generate New Inspiration
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredItems?.map((item) => (
                  <Card key={item.id} className="overflow-hidden group">
                    <div 
                      className="relative aspect-square cursor-pointer"
                      onClick={() => openItemDetail(item)}
                    >
                      <img 
                        src={item.imageUrl} 
                        alt={item.title}
                        className="object-cover w-full h-full"
                      />
                      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <p className="text-white text-center px-4">{item.description}</p>
                      </div>
                    </div>
                    <CardFooter className="p-3 flex justify-between items-center">
                      <div>
                        <Badge variant="outline" className="mr-2">
                          {item.category.charAt(0).toUpperCase() + item.category.slice(1).replace(/-/g, ' ')}
                        </Badge>
                        {item.aiGenerated && (
                          <Badge variant="secondary">AI Generated</Badge>
                        )}
                      </div>
                      <div className="flex space-x-3">
                        <button 
                          className="flex items-center text-muted-foreground hover:text-primary transition-colors"
                          onClick={() => handleInteraction(item.id, 'like')}
                        >
                          <Heart className="h-4 w-4 mr-1" />
                          <span className="text-xs">{item.likes}</span>
                        </button>
                        <button 
                          className="flex items-center text-muted-foreground hover:text-primary transition-colors"
                          onClick={() => handleInteraction(item.id, 'share')}
                        >
                          <Share2 className="h-4 w-4 mr-1" />
                          <span className="text-xs">{item.shares}</span>
                        </button>
                        <div className="flex items-center text-muted-foreground">
                          <Eye className="h-4 w-4 mr-1" />
                          <span className="text-xs">{item.views}</span>
                        </div>
                      </div>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="generate" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Generate AI Inspiration</CardTitle>
                <CardDescription>
                  Describe what you want to see, and our AI will generate a visual preview
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmitGenerate)} className="space-y-6">
                    <FormField
                      control={form.control}
                      name="prompt"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Prompt</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Describe what you want to see, e.g. 'A serene beach scene with palm trees at sunset'"
                              {...field}
                              rows={4}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="style"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Style</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a style" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="realistic">Realistic</SelectItem>
                                <SelectItem value="artistic">Artistic</SelectItem>
                                <SelectItem value="anime">Anime</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="category"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Category</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a category" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="social-media">Social Media</SelectItem>
                                <SelectItem value="product">Product</SelectItem>
                                <SelectItem value="lifestyle">Lifestyle</SelectItem>
                                <SelectItem value="travel">Travel</SelectItem>
                                <SelectItem value="food">Food</SelectItem>
                                <SelectItem value="fashion">Fashion</SelectItem>
                                <SelectItem value="nature">Nature</SelectItem>
                                <SelectItem value="abstract">Abstract</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <Button 
                      type="submit" 
                      className="w-full" 
                      disabled={isGenerating}
                    >
                      {isGenerating ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Generating...
                        </>
                      ) : (
                        <>
                          <ImageIcon className="mr-2 h-4 w-4" />
                          Generate Image
                        </>
                      )}
                    </Button>
                    
                    <p className="text-xs text-muted-foreground text-center mt-4">
                      AI generation may take up to 30 seconds depending on server load.
                      Generated images will be added to the public inspiration gallery.
                    </p>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Detail Dialog */}
      {selectedItem && (
        <Dialog open={Boolean(selectedItem)} onOpenChange={(open) => !open && setSelectedItem(null)}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>{selectedItem.title}</DialogTitle>
              <DialogDescription>
                {selectedItem.description}
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="aspect-square relative">
                <img 
                  src={selectedItem.imageUrl} 
                  alt={selectedItem.title}
                  className="object-cover w-full h-full rounded-md"
                />
              </div>
              
              <div>
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium mb-1">Details</h4>
                    <div className="flex flex-wrap gap-2 mb-4">
                      <Badge variant="outline">
                        {selectedItem.category.charAt(0).toUpperCase() + selectedItem.category.slice(1).replace(/-/g, ' ')}
                      </Badge>
                      {selectedItem.aiGenerated && (
                        <Badge variant="secondary">AI Generated</Badge>
                      )}
                    </div>
                  </div>
                  
                  {selectedItem.tags && Array.isArray(selectedItem.tags) && selectedItem.tags.length > 0 && (
                    <div>
                      <h4 className="text-sm font-medium mb-1">Tags</h4>
                      <div className="flex flex-wrap gap-2">
                        {selectedItem.tags.map((tag, index) => (
                          <Badge key={index} variant="outline">{tag}</Badge>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {selectedItem.settings && (
                    <div>
                      <h4 className="text-sm font-medium mb-1">Generation Settings</h4>
                      <ScrollArea className="h-32 rounded-md border p-4">
                        <div className="space-y-2">
                          {selectedItem.settings.prompt && (
                            <div>
                              <span className="text-xs font-medium">Prompt:</span>
                              <p className="text-sm">{selectedItem.settings.prompt}</p>
                            </div>
                          )}
                          {selectedItem.settings.style && (
                            <div>
                              <span className="text-xs font-medium">Style:</span>
                              <p className="text-sm">{selectedItem.settings.style}</p>
                            </div>
                          )}
                        </div>
                      </ScrollArea>
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            <DialogFooter className="flex justify-between items-center">
              <div className="flex space-x-4">
                <button 
                  className="flex items-center text-muted-foreground hover:text-primary transition-colors"
                  onClick={() => handleInteraction(selectedItem.id, 'like')}
                >
                  <Heart className="h-5 w-5 mr-1" />
                  <span>{selectedItem.likes}</span>
                </button>
                <button 
                  className="flex items-center text-muted-foreground hover:text-primary transition-colors"
                  onClick={() => handleInteraction(selectedItem.id, 'share')}
                >
                  <Share2 className="h-5 w-5 mr-1" />
                  <span>{selectedItem.shares}</span>
                </button>
                <div className="flex items-center text-muted-foreground">
                  <Eye className="h-5 w-5 mr-1" />
                  <span>{selectedItem.views}</span>
                </div>
              </div>
              <Button 
                onClick={() => {
                  // Set form values based on the selected item
                  if (selectedItem.settings?.prompt) {
                    form.setValue("prompt", selectedItem.settings.prompt as string);
                  }
                  if (selectedItem.settings?.style) {
                    form.setValue("style", selectedItem.settings.style as string);
                  }
                  form.setValue("category", selectedItem.category);
                  
                  // Close dialog and switch to generate tab
                  setSelectedItem(null);
                  setActiveTab("generate");
                }}
              >
                Use as Template
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default InspirationGalleryPage;