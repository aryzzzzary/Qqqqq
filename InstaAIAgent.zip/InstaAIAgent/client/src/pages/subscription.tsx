import { SubscriptionManagement } from "@/components/dashboard/subscription-management";
import { Header } from "@/components/layout/header";
import { Card } from "@/components/ui/card";

export default function SubscriptionPage() {
  return (
    <div className="flex flex-col p-6 gap-6">
      <Header title="Subscription Management" />
      
      <Card className="p-6">
        <SubscriptionManagement />
      </Card>
    </div>
  );
}