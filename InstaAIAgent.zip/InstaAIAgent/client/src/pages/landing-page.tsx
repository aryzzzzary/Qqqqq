import React from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  ArrowRight,
  Zap,
  TrendingUp,
  MessageCircle,
  BarChart3,
  Check,
  Star,
  ChevronRight,
  Play,
} from "lucide-react";

// Landing page based on best practice guidelines
export default function LandingPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Navigation */}
      <header className="w-full py-4 px-8 flex items-center justify-between bg-background border-b">
        <div className="flex items-center">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 via-blue-500 to-indigo-400 text-transparent bg-clip-text">Jarvis AI</h1>
        </div>
        <nav className="hidden md:flex items-center space-x-6">
          <a href="#features" className="text-foreground/80 hover:text-foreground transition-colors">Features</a>
          <a href="#pricing" className="text-foreground/80 hover:text-foreground transition-colors">Pricing</a>
          <a href="#testimonials" className="text-foreground/80 hover:text-foreground transition-colors">Testimonials</a>
          <a href="/blog" className="text-foreground/80 hover:text-foreground transition-colors">Blog</a>
        </nav>
        <div className="flex items-center space-x-4">
          <Link href="/auth">
            <Button variant="ghost">Login</Button>
          </Link>
          <Link href="/auth">
            <Button>Sign Up Free</Button>
          </Link>
        </div>
      </header>

      {/* Hero Section (Above the Fold) */}
      <section className="w-full py-20 px-8 bg-gradient-to-b from-background to-background/95">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold leading-tight">
                Your AI-Powered Instagram Growth Assistant
              </h1>
              <p className="mt-4 text-xl text-foreground/80">
                Automate content creation, optimize hashtags, and grow your audience effortlessly with Jarvis AI.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/auth">
                <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white w-full sm:w-auto">
                  Get Started Free <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Button size="lg" variant="outline" className="w-full sm:w-auto">
                <Play className="mr-2 h-4 w-4" /> See Jarvis in Action
              </Button>
            </div>
            
            <div className="flex flex-col sm:items-center space-y-2 border rounded-lg p-4 bg-background/50">
              <div className="flex">
                {Array(5).fill(0).map((_, i) => (
                  <Star key={i} className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                ))}
              </div>
              <p className="text-sm text-foreground/70">Trusted by 10,000+ Instagram Creators & Brands</p>
              <div className="flex flex-wrap justify-center gap-4 text-xs font-medium text-foreground/60">
                <span>TechCrunch</span>
                <span>•</span>
                <span>Forbes</span>
                <span>•</span>
                <span>Instagram Insider</span>
              </div>
            </div>
          </div>
          
          <div className="relative rounded-xl overflow-hidden shadow-2xl border bg-background/20">
            <div className="aspect-[4/3] bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-blue-950/30 dark:via-indigo-950/30 dark:to-purple-950/30 flex items-center justify-center p-8">
              <div className="relative w-full max-w-md mx-auto">
                {/* Placeholder for app demo animation/screenshot */}
                <div className="rounded-md overflow-hidden border shadow-md bg-background">
                  <div className="h-8 bg-muted flex items-center px-3 border-b">
                    <div className="flex space-x-2">
                      <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                      <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    </div>
                  </div>
                  <div className="p-4 space-y-4">
                    <div className="h-8 bg-muted/60 rounded-md w-2/3"></div>
                    <div className="grid grid-cols-3 gap-2">
                      <div className="h-24 bg-muted/40 rounded-md"></div>
                      <div className="h-24 bg-muted/40 rounded-md"></div>
                      <div className="h-24 bg-muted/40 rounded-md"></div>
                    </div>
                    <div className="flex justify-end">
                      <div className="h-8 bg-blue-500/80 rounded-md w-1/3"></div>
                    </div>
                  </div>
                </div>
                {/* Floating interface elements for decoration */}
                <div className="absolute -right-4 top-12 h-20 w-20 bg-blue-100 dark:bg-blue-900/30 rounded-lg shadow-lg flex items-center justify-center border">
                  <TrendingUp className="h-8 w-8 text-blue-500" />
                </div>
                <div className="absolute -left-6 -bottom-4 h-16 w-24 bg-purple-100 dark:bg-purple-900/30 rounded-lg shadow-lg flex items-center justify-center border">
                  <MessageCircle className="h-6 w-6 text-purple-500 mr-1" />
                  <span className="text-sm font-bold text-purple-500">+48%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pain Points & Solution Section */}
      <section className="w-full py-16 px-8 bg-muted/30">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <h2 className="text-3xl font-bold">The Problem: Managing Instagram is Time-Consuming</h2>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <div className="mr-4 mt-1 flex h-8 w-8 items-center justify-center rounded-full bg-red-100 dark:bg-red-900/20">
                    <span className="text-red-600 text-lg">🔹</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold">Keeping up with trends is exhausting</h3>
                    <p className="text-foreground/70 mt-1">Spending hours researching what's working now only to see it change tomorrow.</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="mr-4 mt-1 flex h-8 w-8 items-center justify-center rounded-full bg-red-100 dark:bg-red-900/20">
                    <span className="text-red-600 text-lg">🔹</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold">Hashtag research takes forever</h3>
                    <p className="text-foreground/70 mt-1">The endless cycle of testing hashtags and checking their performance.</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="mr-4 mt-1 flex h-8 w-8 items-center justify-center rounded-full bg-red-100 dark:bg-red-900/20">
                    <span className="text-red-600 text-lg">🔹</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold">Engagement feels like a full-time job</h3>
                    <p className="text-foreground/70 mt-1">Responding to comments, engaging with followers, and growing your audience becomes overwhelming.</p>
                  </div>
                </li>
              </ul>
            </div>
            
            <div className="space-y-8">
              <h2 className="text-3xl font-bold">The Solution: Meet Jarvis AI</h2>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <div className="mr-4 mt-1 flex h-8 w-8 items-center justify-center rounded-full bg-blue-100 dark:bg-blue-900/20">
                    <span className="text-blue-600 text-lg">📌</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold">Content Automation</h3>
                    <p className="text-foreground/70 mt-1">Generates viral-worthy captions & posts in seconds based on your brand voice.</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="mr-4 mt-1 flex h-8 w-8 items-center justify-center rounded-full bg-blue-100 dark:bg-blue-900/20">
                    <span className="text-blue-600 text-lg">📌</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold">Smart Hashtag Optimization</h3>
                    <p className="text-foreground/70 mt-1">AI-powered hashtag suggestions for maximum reach based on real-time performance data.</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="mr-4 mt-1 flex h-8 w-8 items-center justify-center rounded-full bg-blue-100 dark:bg-blue-900/20">
                    <span className="text-blue-600 text-lg">📌</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold">Growth Insights</h3>
                    <p className="text-foreground/70 mt-1">Real-time analytics & personalized recommendations to grow your account strategically.</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="mr-4 mt-1 flex h-8 w-8 items-center justify-center rounded-full bg-blue-100 dark:bg-blue-900/20">
                    <span className="text-blue-600 text-lg">📌</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold">Auto DM & Engagement</h3>
                    <p className="text-foreground/70 mt-1">Increase followers with automated interactions that feel personal and authentic.</p>
                  </div>
                </li>
              </ul>
              
              <div className="pt-4">
                <Link href="/auth">
                  <Button size="lg" className="w-full sm:w-auto">
                    Start Automating Your Growth <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Social Proof Section */}
      <section id="testimonials" className="w-full py-16 px-8">
        <div className="max-w-7xl mx-auto space-y-12">
          <div className="text-center space-y-4">
            <h2 className="text-3xl font-bold">Our Users Are Seeing Real Results</h2>
            <p className="text-xl text-foreground/70 max-w-2xl mx-auto">
              Thousands of creators and brands are using Jarvis AI to skyrocket their Instagram growth.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="overflow-hidden">
              <CardContent className="p-0">
                <div className="p-6 space-y-4">
                  <div className="flex items-center space-x-2">
                    {Array(5).fill(0).map((_, i) => (
                      <Star key={i} className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                    ))}
                  </div>
                  <p className="text-foreground/80 italic">
                    "Jarvis AI doubled my engagement in just 3 weeks! I spend 80% less time on content creation."
                  </p>
                  <div className="flex items-center pt-4">
                    <div className="mr-3 h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                      <span className="font-semibold text-blue-700">SG</span>
                    </div>
                    <div>
                      <p className="font-medium">Sarah Jensen</p>
                      <p className="text-sm text-foreground/60">@SarahSocialGuru</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="overflow-hidden">
              <CardContent className="p-0">
                <div className="p-6 space-y-4">
                  <div className="flex items-center space-x-2">
                    {Array(5).fill(0).map((_, i) => (
                      <Star key={i} className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                    ))}
                  </div>
                  <p className="text-foreground/80 italic">
                    "I grew from 5K to 50K followers using Jarvis's AI automation! The content suggestions are spot on."
                  </p>
                  <div className="flex items-center pt-4">
                    <div className="mr-3 h-10 w-10 rounded-full bg-green-100 flex items-center justify-center">
                      <span className="font-semibold text-green-700">MP</span>
                    </div>
                    <div>
                      <p className="font-medium">Mark Peterson</p>
                      <p className="text-sm text-foreground/60">@MarkMarketingPro</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="overflow-hidden">
              <CardContent className="p-0">
                <div className="p-6 space-y-4">
                  <div className="flex items-center space-x-2">
                    {Array(5).fill(0).map((_, i) => (
                      <Star key={i} className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                    ))}
                  </div>
                  <p className="text-foreground/80 italic">
                    "The analytics and engagement automation are game-changers for our agency. We've been able to 3x our client roster."
                  </p>
                  <div className="flex items-center pt-4">
                    <div className="mr-3 h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center">
                      <span className="font-semibold text-purple-700">JD</span>
                    </div>
                    <div>
                      <p className="font-medium">Jamie Davis</p>
                      <p className="text-sm text-foreground/60">@SocialMediaAgency</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Mini Case Study */}
          <div className="mt-16 bg-muted/30 rounded-xl p-8 border">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
              <div className="space-y-6">
                <h3 className="text-2xl font-bold">Case Study: From Struggling Creator to Thriving Influencer</h3>
                <p className="text-foreground/80">
                  When lifestyle creator Alex started using Jarvis AI, they were stuck at 2,500 followers despite posting consistently for a year. The analytics dashboard identified optimal posting times, content gaps, and engagement opportunities.
                </p>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-2" />
                    <p>+375% follower growth in 3 months</p>
                  </div>
                  <div className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-2" />
                    <p>+150% engagement rate improvement</p>
                  </div>
                  <div className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-2" />
                    <p>+5 brand sponsorship deals secured</p>
                  </div>
                </div>
                <div className="pt-4">
                  <Link href="/auth">
                    <Button size="lg">Try Jarvis for Free</Button>
                  </Link>
                </div>
              </div>
              
              <div className="bg-white dark:bg-background rounded-xl p-6 shadow-lg border">
                <h4 className="font-semibold text-lg text-center mb-6">Growth Results with Jarvis AI</h4>
                <div className="space-y-6">
                  {/* Followers Chart (Simplified Representation) */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Followers</span>
                      <span className="text-sm font-bold text-green-500">+375%</span>
                    </div>
                    <div className="h-6 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-blue-500 to-purple-500 rounded-full" style={{ width: "20%" }}></div>
                    </div>
                    <div className="h-6 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-blue-500 to-purple-500 rounded-full" style={{ width: "95%" }}></div>
                    </div>
                    <div className="flex justify-between text-xs text-foreground/60">
                      <span>Before: 2,500</span>
                      <span>After: 12,000</span>
                    </div>
                  </div>
                  
                  {/* Engagement Chart */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Engagement Rate</span>
                      <span className="text-sm font-bold text-green-500">+150%</span>
                    </div>
                    <div className="h-6 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-green-500 to-emerald-500 rounded-full" style={{ width: "30%" }}></div>
                    </div>
                    <div className="h-6 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-green-500 to-emerald-500 rounded-full" style={{ width: "75%" }}></div>
                    </div>
                    <div className="flex justify-between text-xs text-foreground/60">
                      <span>Before: 2.4%</span>
                      <span>After: 6.0%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Section */}
      <section id="features" className="w-full py-16 px-8 bg-background/95">
        <div className="max-w-7xl mx-auto space-y-12">
          <div className="text-center space-y-4">
            <h2 className="text-3xl font-bold">How Jarvis AI Works</h2>
            <p className="text-xl text-foreground/70 max-w-2xl mx-auto">
              Our AI-powered platform handles the heavy lifting of Instagram management so you can focus on creating.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-gradient-to-br from-white/5 to-white/10 dark:from-white/5 dark:to-transparent p-8 rounded-xl border space-y-4">
              <div className="h-12 w-12 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                <Zap className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold">AI Content Generator</h3>
              <p className="text-foreground/80">
                Automatically create engaging posts, captions, and carousel ideas that align with your brand voice and audience preferences.
              </p>
              <ul className="space-y-2 pt-2">
                <li className="flex items-center">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  <span className="text-sm">Brand-specific content recommendations</span>
                </li>
                <li className="flex items-center">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  <span className="text-sm">Trending topic integration</span>
                </li>
                <li className="flex items-center">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  <span className="text-sm">One-click content generation</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-gradient-to-br from-white/5 to-white/10 dark:from-white/5 dark:to-transparent p-8 rounded-xl border space-y-4">
              <div className="h-12 w-12 rounded-lg bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-purple-600" />
              </div>
              <h3 className="text-xl font-bold">Smart Hashtag & Trend Analyzer</h3>
              <p className="text-foreground/80">
                AI-powered hashtag recommendations & real-time trend tracking to ensure your content reaches the right audience.
              </p>
              <ul className="space-y-2 pt-2">
                <li className="flex items-center">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  <span className="text-sm">Hashtag performance analysis</span>
                </li>
                <li className="flex items-center">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  <span className="text-sm">Trending content discovery</span>
                </li>
                <li className="flex items-center">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  <span className="text-sm">Competitor hashtag insights</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-gradient-to-br from-white/5 to-white/10 dark:from-white/5 dark:to-transparent p-8 rounded-xl border space-y-4">
              <div className="h-12 w-12 rounded-lg bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                <MessageCircle className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-xl font-bold">Automated Engagement & DM Outreach</h3>
              <p className="text-foreground/80">
                Auto-replies, comment management, and targeted follower growth to build your community while you focus on creating.
              </p>
              <ul className="space-y-2 pt-2">
                <li className="flex items-center">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  <span className="text-sm">Personalized auto-comments</span>
                </li>
                <li className="flex items-center">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  <span className="text-sm">Smart DM campaigns</span>
                </li>
                <li className="flex items-center">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  <span className="text-sm">Follower growth automation</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-gradient-to-br from-white/5 to-white/10 dark:from-white/5 dark:to-transparent p-8 rounded-xl border space-y-4">
              <div className="h-12 w-12 rounded-lg bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center">
                <BarChart3 className="h-6 w-6 text-amber-600" />
              </div>
              <h3 className="text-xl font-bold">Smart Analytics Dashboard</h3>
              <p className="text-foreground/80">
                Actionable insights for optimizing engagement and growth with data-driven recommendations tailored to your account.
              </p>
              <ul className="space-y-2 pt-2">
                <li className="flex items-center">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  <span className="text-sm">Performance tracking</span>
                </li>
                <li className="flex items-center">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  <span className="text-sm">Audience insights</span>
                </li>
                <li className="flex items-center">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  <span className="text-sm">Growth opportunity alerts</span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="text-center pt-8">
            <Link href="/auth">
              <Button size="lg">
                Start Growing Smarter <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="w-full py-16 px-8 bg-muted/30">
        <div className="max-w-7xl mx-auto space-y-12">
          <div className="text-center space-y-4">
            <h2 className="text-3xl font-bold">Simple, Transparent Pricing – Start for Free</h2>
            <p className="text-xl text-foreground/70 max-w-2xl mx-auto">
              Choose the plan that's right for you and start growing your Instagram presence today.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Free Plan */}
            <Card className="relative overflow-hidden">
              <CardContent className="p-6 pt-8">
                <div className="space-y-6">
                  <div>
                    <h3 className="text-2xl font-bold">Free</h3>
                    <p className="text-foreground/70 mt-1">Perfect for getting started</p>
                  </div>
                  
                  <div className="flex items-baseline">
                    <span className="text-4xl font-bold">$0</span>
                    <span className="text-foreground/70 ml-2">/month</span>
                  </div>
                  
                  <ul className="space-y-3">
                    <li className="flex">
                      <Check className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                      <span>Basic AI content suggestions</span>
                    </li>
                    <li className="flex">
                      <Check className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                      <span>Limited analytics</span>
                    </li>
                    <li className="flex">
                      <Check className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                      <span>1 Instagram account</span>
                    </li>
                    <li className="flex">
                      <Check className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                      <span>5 AI-generated posts/month</span>
                    </li>
                    <li className="flex text-foreground/50">
                      <Check className="h-5 w-5 text-foreground/30 mr-2 shrink-0" />
                      <span>No automated engagement</span>
                    </li>
                  </ul>
                  
                  <Link href="/auth">
                    <Button variant="outline" className="w-full">
                      Get Started
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
            
            {/* Pro Plan */}
            <Card className="relative overflow-hidden shadow-lg border-blue-200 dark:border-blue-800">
              <div className="absolute top-0 right-0 bg-blue-600 text-white px-3 py-1 text-xs font-medium">
                MOST POPULAR
              </div>
              <CardContent className="p-6 pt-8">
                <div className="space-y-6">
                  <div>
                    <h3 className="text-2xl font-bold">Pro</h3>
                    <p className="text-foreground/70 mt-1">For serious creators</p>
                  </div>
                  
                  <div className="flex items-baseline">
                    <span className="text-4xl font-bold">$29</span>
                    <span className="text-foreground/70 ml-2">/month</span>
                  </div>
                  
                  <ul className="space-y-3">
                    <li className="flex">
                      <Check className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                      <span>Full AI content generation</span>
                    </li>
                    <li className="flex">
                      <Check className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                      <span>Advanced analytics dashboard</span>
                    </li>
                    <li className="flex">
                      <Check className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                      <span>1 Instagram account</span>
                    </li>
                    <li className="flex">
                      <Check className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                      <span>Unlimited AI-generated posts</span>
                    </li>
                    <li className="flex">
                      <Check className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                      <span>Basic automated engagement</span>
                    </li>
                    <li className="flex">
                      <Check className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                      <span>Premium email support</span>
                    </li>
                  </ul>
                  
                  <div className="pt-4">
                    <div className="text-sm text-blue-600 font-medium mb-3 flex items-center justify-center">
                      <Zap className="h-4 w-4 mr-1" />
                      <span>Try PRO for 7 Days – No Credit Card Required!</span>
                    </div>
                    <Link href="/auth">
                      <Button className="w-full bg-blue-600 hover:bg-blue-700">
                        Start Free Trial
                      </Button>
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Business Plan */}
            <Card className="relative overflow-hidden">
              <CardContent className="p-6 pt-8">
                <div className="space-y-6">
                  <div>
                    <h3 className="text-2xl font-bold">Business</h3>
                    <p className="text-foreground/70 mt-1">For agencies & brands</p>
                  </div>
                  
                  <div className="flex items-baseline">
                    <span className="text-4xl font-bold">$99</span>
                    <span className="text-foreground/70 ml-2">/month</span>
                  </div>
                  
                  <ul className="space-y-3">
                    <li className="flex">
                      <Check className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                      <span>Everything in Pro plan</span>
                    </li>
                    <li className="flex">
                      <Check className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                      <span>Up to 5 Instagram accounts</span>
                    </li>
                    <li className="flex">
                      <Check className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                      <span>Advanced automated engagement</span>
                    </li>
                    <li className="flex">
                      <Check className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                      <span>Team collaboration tools</span>
                    </li>
                    <li className="flex">
                      <Check className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                      <span>White label reporting</span>
                    </li>
                    <li className="flex">
                      <Check className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                      <span>Priority support & training</span>
                    </li>
                  </ul>
                  
                  <Link href="/auth">
                    <Button variant="outline" className="w-full">
                      Contact Sales
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* FAQs Section */}
      <section className="w-full py-16 px-8">
        <div className="max-w-4xl mx-auto space-y-8">
          <div className="text-center space-y-4">
            <h2 className="text-3xl font-bold">Frequently Asked Questions</h2>
            <p className="text-xl text-foreground/70">
              Got questions? We've got answers.
            </p>
          </div>
          
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="faq-1">
              <AccordionTrigger>Do I need Instagram experience to use Jarvis?</AccordionTrigger>
              <AccordionContent>
                Not at all! Jarvis AI is designed to be user-friendly for beginners and experts alike. Our setup wizard will guide you through connecting your Instagram account, and our AI assistant will provide recommendations tailored to your specific goals.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="faq-2">
              <AccordionTrigger>Will this get me banned from Instagram?</AccordionTrigger>
              <AccordionContent>
                No, Jarvis AI is built to comply with Instagram's terms of service. Our system follows Instagram's best practices and rate limits to ensure your account remains in good standing. Our engagement features mimic natural human behavior and avoid spam-like activities.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="faq-3">
              <AccordionTrigger>How quickly will I see results?</AccordionTrigger>
              <AccordionContent>
                Most users begin seeing improved engagement within the first week of using Jarvis AI. For follower growth, results typically become noticeable within 2-4 weeks, depending on your niche and how consistently you implement our AI-powered recommendations.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="faq-4">
              <AccordionTrigger>Can I cancel my subscription anytime?</AccordionTrigger>
              <AccordionContent>
                Yes, you can cancel your subscription at any time with no questions asked. Once canceled, you'll continue to have access to your paid features until the end of your current billing period, then automatically transition to the free plan.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="faq-5">
              <AccordionTrigger>How does Jarvis AI generate content?</AccordionTrigger>
              <AccordionContent>
                Jarvis uses advanced natural language processing and computer vision AI to analyze your previous content, your brand voice, and trending content in your niche. It then generates original captions, post ideas, and hashtag recommendations tailored specifically to your account's unique style and audience.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="faq-6">
              <AccordionTrigger>Do you offer refunds?</AccordionTrigger>
              <AccordionContent>
                Yes, we offer a 14-day money-back guarantee if you're not satisfied with your Pro or Business subscription. Simply contact our support team within 14 days of your purchase to request a refund.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="w-full py-16 px-8 bg-gradient-to-br from-blue-50 via-indigo-50 to-blue-50 dark:from-blue-950/30 dark:via-indigo-950/30 dark:to-blue-950/30">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <h2 className="text-3xl md:text-4xl font-bold">🚀 Ready to Grow Faster?</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex flex-col items-center p-4">
              <div className="h-12 w-12 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center mb-4">
                <Zap className="h-6 w-6 text-blue-600" />
              </div>
              <p className="text-foreground/80 text-center">AI-powered automation saves you time</p>
            </div>
            
            <div className="flex flex-col items-center p-4">
              <div className="h-12 w-12 rounded-full bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center mb-4">
                <TrendingUp className="h-6 w-6 text-purple-600" />
              </div>
              <p className="text-foreground/80 text-center">Gain more engagement with data-driven content</p>
            </div>
            
            <div className="flex flex-col items-center p-4">
              <div className="h-12 w-12 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center mb-4">
                <MessageCircle className="h-6 w-6 text-green-600" />
              </div>
              <p className="text-foreground/80 text-center">Get started in less than 60 seconds</p>
            </div>
          </div>
          
          <div className="pt-6 space-y-4">
            <Link href="/auth">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white px-8">
                Sign Up for Free Now <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            <div>
              <Button variant="link" size="sm" className="text-foreground/70">
                <Play className="mr-2 h-3 w-3" /> Watch Demo
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="w-full py-12 px-8 bg-muted/50 border-t">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <h3 className="text-lg font-bold">Jarvis AI</h3>
              <p className="text-sm text-foreground/70">
                AI-powered Instagram growth assistant for creators and brands.
              </p>
            </div>
            
            <div>
              <h4 className="font-medium mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li>
                  <a href="#features" className="text-sm text-foreground/70 hover:text-foreground">Features</a>
                </li>
                <li>
                  <a href="#pricing" className="text-sm text-foreground/70 hover:text-foreground">Pricing</a>
                </li>
                <li>
                  <Link href="/blog" className="text-sm text-foreground/70 hover:text-foreground">Blog</Link>
                </li>
                <li>
                  <a href="#" className="text-sm text-foreground/70 hover:text-foreground">Contact</a>
                </li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium mb-4">Legal</h4>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="text-sm text-foreground/70 hover:text-foreground">Privacy Policy</a>
                </li>
                <li>
                  <a href="#" className="text-sm text-foreground/70 hover:text-foreground">Terms of Service</a>
                </li>
                <li>
                  <a href="#" className="text-sm text-foreground/70 hover:text-foreground">Cookie Policy</a>
                </li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium mb-4">Connect</h4>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="text-sm text-foreground/70 hover:text-foreground">Instagram</a>
                </li>
                <li>
                  <a href="#" className="text-sm text-foreground/70 hover:text-foreground">Twitter</a>
                </li>
                <li>
                  <a href="#" className="text-sm text-foreground/70 hover:text-foreground">LinkedIn</a>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="mt-12 pt-8 border-t border-border/50 flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-foreground/60 mb-4 md:mb-0">
              © {new Date().getFullYear()} Jarvis AI. All rights reserved.
            </p>
            <div className="flex space-x-6">
              <a href="#" className="text-foreground/60 hover:text-foreground">
                <span className="sr-only">Instagram</span>
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                  <path fillRule="evenodd" d="M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.067.06 1.407.06 4.123v.08c0 2.643-.012 2.987-.06 4.043-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.067.048-1.407.06-4.123.06h-.08c-2.643 0-2.987-.012-4.043-.06-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.047-1.024-.06-1.379-.06-3.808v-.63c0-2.43.013-2.784.06-3.808.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772A4.902 4.902 0 015.45 2.525c.636-.247 1.363-.416 2.427-.465C8.901 2.013 9.256 2 11.685 2h.63zm-.081 1.802h-.468c-2.456 0-2.784.011-3.807.058-.975.045-1.504.207-1.857.344-.467.182-.8.398-1.15.748-.35.35-.566.683-.748 1.15-.137.353-.3.882-.344 1.857-.047 1.023-.058 1.351-.058 3.807v.468c0 2.456.011 2.784.058 3.807.045.975.207 1.504.344 1.857.182.466.399.8.748 1.15.35.35.683.566 1.15.748.353.137.882.3 1.857.344 1.054.048 1.37.058 4.041.058h.08c2.597 0 2.917-.01 3.96-.058.976-.045 1.505-.207 1.858-.344.466-.182.8-.398 1.15-.748.35-.35.566-.683.748-1.15.137-.353.3-.882.344-1.857.048-1.055.058-1.37.058-4.041v-.08c0-2.597-.01-2.917-.058-3.96-.045-.976-.207-1.505-.344-1.858a3.097 3.097 0 00-.748-1.15 3.098 3.098 0 00-1.15-.748c-.353-.137-.882-.3-1.857-.344-1.023-.047-1.351-.058-3.807-.058zM12 6.865a5.135 5.135 0 110 10.27 5.135 5.135 0 010-10.27zm0 1.802a3.333 3.333 0 100 6.666 3.333 3.333 0 000-6.666zm5.338-3.205a1.2 1.2 0 110 2.4 1.2 1.2 0 010-2.4z" clipRule="evenodd"></path>
                </svg>
              </a>
              <a href="#" className="text-foreground/60 hover:text-foreground">
                <span className="sr-only">Twitter</span>
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84"></path>
                </svg>
              </a>
              <a href="#" className="text-foreground/60 hover:text-foreground">
                <span className="sr-only">LinkedIn</span>
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"></path>
                </svg>
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}