import { ConnectionStatus } from "@/components/dashboard/connection-status";
import { AnalyticsSummary } from "@/components/dashboard/analytics-summary";
import { UpcomingPosts } from "@/components/dashboard/upcoming-posts";
import { ContentGenerator } from "@/components/dashboard/content-generator";
import { EngagementAutomation } from "@/components/dashboard/engagement-automation";
import { SecurityModule } from "@/components/dashboard/security-module";

export default function Dashboard() {
  return (
    <main className="p-4 md:p-6">
      <ConnectionStatus />
      
      <AnalyticsSummary />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <UpcomingPosts />
        <ContentGenerator />
      </div>
      
      <EngagementAutomation />
      
      <SecurityModule />
    </main>
  );
}
