import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Loader2, Calendar, Tag, ArrowLeft, Share2 } from "lucide-react";

interface BlogPost {
  id: number;
  title: string;
  slug: string;
  summary: string;
  content: string;
  publishedAt: string;
  tags: string[];
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  relatedPosts: {
    id: number;
    title: string;
    slug: string;
  }[];
  featuredImage?: string;
  authorName: string;
}

export default function BlogPostPage() {
  const [, params] = useRoute("/blog/:slug");
  const slug = params?.slug;
  
  const { data: post, isLoading, error } = useQuery<BlogPost>({
    queryKey: [`/api/blog/slug/${slug}`],
    queryFn: async () => {
      const res = await fetch(`/api/blog/slug/${slug}`);
      if (!res.ok) throw new Error("Failed to fetch blog post");
      return res.json();
    },
    enabled: !!slug
  });

  // Update document metadata for SEO
  useEffect(() => {
    if (post) {
      // Set document title
      document.title = post.seoTitle || post.title;
      
      // Update meta tags for SEO
      let metaDescription = document.querySelector('meta[name="description"]');
      if (!metaDescription) {
        metaDescription = document.createElement('meta');
        metaDescription.setAttribute('name', 'description');
        document.head.appendChild(metaDescription);
      }
      metaDescription.setAttribute('content', post.seoDescription || post.summary);
      
      // Update keywords
      let metaKeywords = document.querySelector('meta[name="keywords"]');
      if (!metaKeywords) {
        metaKeywords = document.createElement('meta');
        metaKeywords.setAttribute('name', 'keywords');
        document.head.appendChild(metaKeywords);
      }
      metaKeywords.setAttribute('content', post.seoKeywords?.join(', ') || post.tags.join(', '));
      
      // Add Open Graph tags for social sharing
      let ogTitle = document.querySelector('meta[property="og:title"]');
      if (!ogTitle) {
        ogTitle = document.createElement('meta');
        ogTitle.setAttribute('property', 'og:title');
        document.head.appendChild(ogTitle);
      }
      ogTitle.setAttribute('content', post.title);
      
      let ogDescription = document.querySelector('meta[property="og:description"]');
      if (!ogDescription) {
        ogDescription = document.createElement('meta');
        ogDescription.setAttribute('property', 'og:description');
        document.head.appendChild(ogDescription);
      }
      ogDescription.setAttribute('content', post.summary);
      
      let ogImage = document.querySelector('meta[property="og:image"]');
      if (!ogImage && post.featuredImage) {
        ogImage = document.createElement('meta');
        ogImage.setAttribute('property', 'og:image');
        document.head.appendChild(ogImage);
        ogImage.setAttribute('content', post.featuredImage);
      }
      
      // Add schema.org structured data for blog post
      const script = document.createElement('script');
      script.type = 'application/ld+json';
      script.text = JSON.stringify({
        "@context": "https://schema.org",
        "@type": "BlogPosting",
        "headline": post.title,
        "description": post.summary,
        "keywords": post.seoKeywords?.join(', ') || post.tags.join(', '),
        "author": {
          "@type": "Person",
          "name": post.authorName || "Instagram AI Agent Team"
        },
        "datePublished": post.publishedAt,
        "image": post.featuredImage,
        "publisher": {
          "@type": "Organization",
          "name": "Instagram AI Agent Platform",
          "logo": {
            "@type": "ImageObject",
            "url": window.location.origin + "/logo.png"
          }
        },
        "mainEntityOfPage": {
          "@type": "WebPage",
          "@id": window.location.href
        }
      });
      document.head.appendChild(script);
      
      return () => {
        document.head.removeChild(script);
      };
    }
  }, [post]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error || !post) {
    return (
      <div className="container mx-auto p-6 text-center">
        <h1 className="text-2xl font-bold mb-4">Blog Post Not Found</h1>
        <p className="text-muted-foreground mb-4">
          The blog post you're looking for doesn't exist or may have been removed.
        </p>
        <Link href="/blog">
          <Button className="mt-2">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Blog
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <main className="container mx-auto p-6">
      <div className="mb-4">
        <Link href="/blog">
          <Button variant="ghost" size="sm">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Blog
          </Button>
        </Link>
      </div>
      
      <article className="max-w-4xl mx-auto">
        {post.featuredImage && (
          <div className="w-full h-72 md:h-96 mb-6 overflow-hidden rounded-lg">
            <img 
              src={post.featuredImage} 
              alt={post.title}
              className="w-full h-full object-cover"
            />
          </div>
        )}
        
        <h1 className="text-3xl md:text-4xl font-bold mb-4">{post.title}</h1>
        
        <div className="flex flex-wrap items-center text-sm text-muted-foreground mb-6">
          <div className="flex items-center mr-4">
            <Calendar className="mr-1 h-4 w-4" />
            <span>{new Date(post.publishedAt).toLocaleDateString()}</span>
          </div>
          
          <div className="flex items-center">
            <Tag className="mr-1 h-4 w-4" />
            <span>
              {post.tags.map((tag, i) => (
                <span key={i} className="mr-2">
                  <Link href={`/blog/tag/${tag}`}>
                    <span className="text-primary hover:underline cursor-pointer">
                      #{tag}
                    </span>
                  </Link>
                </span>
              ))}
            </span>
          </div>
        </div>
        
        <div className="prose prose-lg max-w-none mb-8" 
          dangerouslySetInnerHTML={{ __html: post.content }}>
        </div>
        
        <div className="flex justify-between items-center mt-8 border-t pt-6">
          <div>
            <Link href="/blog">
              <Button variant="outline">
                <ArrowLeft className="mr-2 h-4 w-4" /> Back to Blog
              </Button>
            </Link>
          </div>
          
          <div>
            <Button variant="ghost" size="sm" className="mr-2">
              <Share2 className="mr-2 h-4 w-4" /> Share
            </Button>
          </div>
        </div>
        
        {post.relatedPosts && post.relatedPosts.length > 0 && (
          <div className="mt-12">
            <h2 className="text-2xl font-bold mb-6">Related Articles</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {post.relatedPosts.map((relatedPost) => (
                <Card key={relatedPost.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <h3 className="font-semibold hover:text-primary transition-colors">
                      <Link href={`/blog/${relatedPost.slug}`}>
                        {relatedPost.title}
                      </Link>
                    </h3>
                    <Link href={`/blog/${relatedPost.slug}`}>
                      <Button variant="link" className="p-0 h-auto mt-2">
                        Read More
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
        
        <div className="mt-12 p-6 bg-muted rounded-lg">
          <h3 className="text-xl font-bold mb-4">Try Our Instagram AI Agent</h3>
          <p className="mb-4">Automate your Instagram content creation and engagement with our powerful AI tools.</p>
          <Link href="/">
            <Button className="bg-gradient-to-r from-blue-500 to-purple-500">
              Explore Platform Features
            </Button>
          </Link>
        </div>
      </article>
    </main>
  );
}