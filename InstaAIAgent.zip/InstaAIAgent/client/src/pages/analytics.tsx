import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { InstagramAnalytics } from "@shared/schema";
import { format, subDays } from "date-fns";
import { 
  ArrowDown, 
  ArrowUp, 
  BarChart3, 
  Calendar, 
  ChevronDown, 
  Download, 
  Users,
  TrendingUp,
  Eye,
  Share2
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Legend,
  PieChart,
  Pie,
  Cell,
} from "recharts";

// Sample data for charts
const followerGrowthData = [
  { date: "May 1", followers: 3120 },
  { date: "May 8", followers: 3220 },
  { date: "May 15", followers: 3280 },
  { date: "May 22", followers: 3350 },
  { date: "May 29", followers: 3420 },
  { date: "Jun 5", followers: 3482 },
];

const engagementData = [
  { date: "May 1", likes: 124, comments: 32, shares: 5 },
  { date: "May 8", likes: 148, comments: 28, shares: 7 },
  { date: "May 15", likes: 162, comments: 45, shares: 12 },
  { date: "May 22", likes: 138, comments: 36, shares: 8 },
  { date: "May 29", likes: 155, comments: 41, shares: 10 },
  { date: "Jun 5", likes: 172, comments: 43, shares: 15 },
];

const postPerformanceData = [
  { id: 1, type: "Image", caption: "Summer Collection Sneak Peek", likes: 324, comments: 56, reach: 2150, engagement: 17.7 },
  { id: 2, type: "Carousel", caption: "Behind the Scenes at the Photo Shoot", likes: 287, comments: 42, reach: 1920, engagement: 17.1 },
  { id: 3, type: "Video", caption: "How Our Products Are Made", likes: 412, comments: 78, reach: 3100, engagement: 15.8 },
  { id: 4, type: "Image", caption: "New Product Announcement", likes: 356, comments: 92, reach: 2750, engagement: 16.3 },
  { id: 5, type: "Carousel", caption: "Customer Testimonials", likes: 298, comments: 63, reach: 2050, engagement: 17.6 },
];

const audienceData = [
  { name: "18-24", value: 30 },
  { name: "25-34", value: 40 },
  { name: "35-44", value: 15 },
  { name: "45-54", value: 10 },
  { name: "55+", value: 5 },
];

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8"];

export default function Analytics() {
  const [period, setPeriod] = useState<string>("7");
  
  const { data, isLoading } = useQuery<InstagramAnalytics>({
    queryKey: ["/api/analytics", { days: period }],
  });
  
  const handlePeriodChange = (value: string) => {
    setPeriod(value);
  };
  
  const renderMetricCard = (
    title: string,
    value: number | string,
    change: number,
    icon: React.ReactNode
  ) => {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500">{title}</p>
              <h3 className="text-2xl font-semibold mt-1">{value}</h3>
            </div>
            <div className="bg-gray-100 p-2 rounded-full">
              {icon}
            </div>
          </div>
          <div className="mt-3 flex items-center">
            <div className={`text-sm flex items-center ${change >= 0 ? "text-[#28A745]" : "text-[#DC3545]"}`}>
              {change >= 0 ? (
                <ArrowUp className="mr-1 h-4 w-4" />
              ) : (
                <ArrowDown className="mr-1 h-4 w-4" />
              )}
              <span>{Math.abs(change)}%</span>
            </div>
            <span className="text-xs text-gray-500 ml-2">vs previous period</span>
          </div>
        </CardContent>
      </Card>
    );
  };
  
  if (isLoading) {
    return (
      <main className="p-4 md:p-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
          <Skeleton className="h-10 w-48" />
          <Skeleton className="h-10 w-36 mt-4 md:mt-0" />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <Skeleton className="h-80" />
          <Skeleton className="h-80" />
        </div>
        
        <Skeleton className="h-96" />
      </main>
    );
  }
  
  return (
    <main className="p-4 md:p-6">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">Analytics</h1>
          <p className="text-gray-500 mt-1">Track and analyze your Instagram performance</p>
        </div>
        <div className="mt-4 md:mt-0 flex items-center gap-2">
          <Select value={period} onValueChange={handlePeriodChange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">Last 7 days</SelectItem>
              <SelectItem value="14">Last 14 days</SelectItem>
              <SelectItem value="30">Last 30 days</SelectItem>
              <SelectItem value="90">Last 3 months</SelectItem>
            </SelectContent>
          </Select>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon">
                <Download className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>
                Export as CSV
              </DropdownMenuItem>
              <DropdownMenuItem>
                Export as PDF
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {data && renderMetricCard(
          "Followers",
          data.followers.count.toLocaleString(),
          data.followers.change,
          <Users className="h-5 w-5 text-[#0095F6]" />
        )}
        {data && renderMetricCard(
          "Engagement Rate",
          `${data.engagement.rate}%`,
          data.engagement.change,
          <TrendingUp className="h-5 w-5 text-[#0095F6]" />
        )}
        {data && renderMetricCard(
          "Post Reach",
          data.postReach.count >= 1000 
            ? `${(data.postReach.count / 1000).toFixed(1)}K` 
            : data.postReach.count.toString(),
          data.postReach.change,
          <Share2 className="h-5 w-5 text-[#0095F6]" />
        )}
        {data && renderMetricCard(
          "Profile Visits",
          data.profileVisits.count.toLocaleString(),
          data.profileVisits.change,
          <Eye className="h-5 w-5 text-[#0095F6]" />
        )}
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Follower Growth</CardTitle>
              <Button variant="ghost" size="sm">
                <Calendar className="h-4 w-4 mr-2" /> {format(subDays(new Date(), 30), "MMM d")} - {format(new Date(), "MMM d")}
              </Button>
            </div>
            <CardDescription>
              Track your follower growth over time
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={followerGrowthData}
                  margin={{ top: 5, right: 20, left: 10, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Line 
                    type="monotone" 
                    dataKey="followers" 
                    stroke="#0095F6" 
                    strokeWidth={2}
                    dot={{ r: 3 }}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Engagement Breakdown</CardTitle>
              <Button variant="ghost" size="sm">
                <Calendar className="h-4 w-4 mr-2" /> {format(subDays(new Date(), 30), "MMM d")} - {format(new Date(), "MMM d")}
              </Button>
            </div>
            <CardDescription>
              Likes, comments, and shares over time
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={engagementData}
                  margin={{ top: 5, right: 20, left: 10, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="likes" name="Likes" fill="#0095F6" />
                  <Bar dataKey="comments" name="Comments" fill="#E1306C" />
                  <Bar dataKey="shares" name="Shares" fill="#8134AF" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <Card className="col-span-2">
          <CardHeader>
            <CardTitle>Top Performing Posts</CardTitle>
            <CardDescription>
              Your highest engaging content in this period
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Post</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Likes</TableHead>
                  <TableHead>Comments</TableHead>
                  <TableHead>Reach</TableHead>
                  <TableHead>Engagement</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {postPerformanceData.map((post) => (
                  <TableRow key={post.id}>
                    <TableCell className="max-w-[200px] truncate font-medium">
                      {post.caption}
                    </TableCell>
                    <TableCell>{post.type}</TableCell>
                    <TableCell>{post.likes.toLocaleString()}</TableCell>
                    <TableCell>{post.comments.toLocaleString()}</TableCell>
                    <TableCell>{post.reach.toLocaleString()}</TableCell>
                    <TableCell>{post.engagement}%</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Audience Demographics</CardTitle>
            <CardDescription>
              Age distribution of your followers
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={audienceData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="value"
                    label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  >
                    {audienceData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value) => [`${value}%`, 'Percentage']}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex justify-center mt-4">
              <div className="grid grid-cols-3 gap-2">
                {audienceData.map((entry, index) => (
                  <div key={index} className="flex items-center">
                    <div 
                      className="w-3 h-3 rounded-full mr-1" 
                      style={{ backgroundColor: COLORS[index % COLORS.length] }}
                    ></div>
                    <span className="text-xs">{entry.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Content Performance by Type</CardTitle>
            <Tabs defaultValue="engagement">
              <TabsList>
                <TabsTrigger value="engagement">Engagement</TabsTrigger>
                <TabsTrigger value="reach">Reach</TabsTrigger>
                <TabsTrigger value="growth">Growth</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
          <CardDescription>
            Compare performance across different content types
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={[
                  { type: "Photos", engagement: 8.2, reach: 2800, growth: 2.3 },
                  { type: "Videos", engagement: 12.4, reach: 4500, growth: 5.1 },
                  { type: "Carousels", engagement: 10.6, reach: 3800, growth: 3.9 },
                  { type: "Reels", engagement: 15.8, reach: 7200, growth: 7.8 },
                  { type: "Stories", engagement: 6.4, reach: 2200, growth: 1.5 },
                ]}
                margin={{ top: 20, right: 30, left: 20, bottom: 30 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="type" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="engagement" name="Engagement Rate (%)" fill="#0095F6" />
                <Bar dataKey="reach" name="Avg. Reach" fill="#E1306C" />
                <Bar dataKey="growth" name="Follower Growth (%)" fill="#FCAF45" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </main>
  );
}
