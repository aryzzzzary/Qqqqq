import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Loader2, Plus } from "lucide-react";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface BlogPost {
  id: number;
  title: string;
  slug: string;
  summary: string;
  content: string;
  publishedAt: string;
  tags: string[];
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  featuredImage?: string;
}

export default function BlogPage() {
  const [currentPage, setCurrentPage] = useState(1);
  const { user } = useAuth();
  const { toast } = useToast();
  
  const { data: blogPosts, isLoading, error, refetch } = useQuery<BlogPost[]>({
    queryKey: ["/api/blog", currentPage],
    queryFn: async () => {
      const res = await fetch(`/api/blog?page=${currentPage}`);
      if (!res.ok) throw new Error("Failed to fetch blog posts");
      return res.json();
    }
  });
  
  // Mutation for generating new blog posts (admin only)
  const generatePostsMutation = useMutation({
    mutationFn: async (count: number) => {
      const res = await apiRequest("POST", "/api/blog/generate", { count });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to generate blog posts");
      }
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Blog posts generated successfully. Refreshing...",
      });
      // Refresh the blog posts list
      refetch();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // For SEO, set document title and meta description
  useEffect(() => {
    document.title = "Instagram AI Agent Blog - Best Practices & Tips";
    
    // Update meta description for SEO
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', 
      'Discover the latest Instagram automation strategies, AI content creation tips, and social media best practices to grow your Instagram presence.');
    
    // Add schema.org structured data for blog
    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.text = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "Blog",
      "headline": "Instagram AI Agent Blog - Best Practices & Tips",
      "description": "Expert advice and strategies for Instagram automation and AI content creation",
      "publisher": {
        "@type": "Organization",
        "name": "Instagram AI Agent Platform",
        "logo": {
          "@type": "ImageObject",
          "url": window.location.origin + "/logo.png"
        }
      }
    });
    document.head.appendChild(script);
    
    return () => {
      document.head.removeChild(script);
    };
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 text-center">
        <h1 className="text-2xl font-bold mb-4">Blog</h1>
        <p className="text-red-500">
          Failed to load blog posts. Please try again later.
        </p>
      </div>
    );
  }

  // Show a default list of blog categories if no posts exist yet
  const categories = [
    "Instagram Growth Strategies",
    "AI Content Creation",
    "Engagement Automation",
    "Social Media Analytics",
    "Instagram Algorithm Updates"
  ];

  return (
    <main className="container mx-auto p-6">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent">
          Instagram AI Strategy Blog
        </h1>
        <p className="mt-2 text-muted-foreground max-w-2xl mx-auto">
          Expert insights, tips, and best practices for automating your Instagram growth and creating
          engaging AI-powered content that converts followers into customers.
        </p>
        
        {/* Admin controls - only show for authenticated users */}
        {user && (
          <div className="mt-4 flex justify-center">
            <Button 
              onClick={() => generatePostsMutation.mutate(1)}
              disabled={generatePostsMutation.isPending}
              variant="outline"
              className="mr-2"
            >
              {generatePostsMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Plus className="mr-2 h-4 w-4" />
                  Generate 1 Blog Post
                </>
              )}
            </Button>
            
            <Button 
              onClick={() => generatePostsMutation.mutate(3)}
              disabled={generatePostsMutation.isPending}
              variant="outline"
            >
              {generatePostsMutation.isPending ? (
                "Please wait..."
              ) : (
                "Generate 3 Blog Posts"
              )}
            </Button>
          </div>
        )}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="md:col-span-3">
          {blogPosts && blogPosts.length > 0 ? (
            <div className="space-y-6">
              {blogPosts.map((post) => (
                <Card key={post.id} className="overflow-hidden">
                  {post.featuredImage && (
                    <div className="w-full h-48 overflow-hidden">
                      <img 
                        src={post.featuredImage} 
                        alt={post.title}
                        className="w-full h-full object-cover hover:scale-105 transition-transform"
                      />
                    </div>
                  )}
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-xl hover:text-primary transition-colors">
                          <Link href={`/blog/${post.slug}`}>
                            {post.title}
                          </Link>
                        </CardTitle>
                        <p className="text-sm text-muted-foreground mt-1">
                          {new Date(post.publishedAt).toLocaleDateString()} • 
                          {post.tags.map((tag, i) => (
                            <span key={i} className="ml-2 text-primary">
                              #{tag}
                            </span>
                          ))}
                        </p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{post.summary}</p>
                    <div className="mt-4">
                      <Link href={`/blog/${post.slug}`}>
                        <Button variant="outline" size="sm">
                          Read More
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              <div className="flex justify-center gap-2 mt-8">
                <Button 
                  variant="outline" 
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                >
                  Previous
                </Button>
                <Button 
                  variant="outline"
                  disabled={!blogPosts || blogPosts.length < 10}
                  onClick={() => setCurrentPage(p => p + 1)}
                >
                  Next
                </Button>
              </div>
            </div>
          ) : (
            <Card className="p-6 text-center">
              <CardContent>
                <p className="mb-4">Our blog posts are being generated. Check back soon for valuable content!</p>
                <p className="text-sm text-muted-foreground">
                  We use AI to create high-quality, SEO-optimized content about Instagram marketing and automation.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
        
        <div>
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Categories</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {categories.map((category, index) => (
                  <div key={index}>
                    <Link href={`/blog/category/${category.toLowerCase().replace(/ /g, '-')}`}>
                      <span className="block py-1 hover:text-primary transition-colors cursor-pointer">
                        {category}
                      </span>
                    </Link>
                    {index < categories.length - 1 && <Separator className="my-1" />}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
          
          <Card className="mt-4">
            <CardHeader>
              <CardTitle className="text-lg">Popular Articles</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">
                  Subscribe to our newsletter to get notified when new articles are published.
                </p>
                <Link href="/">
                  <Button className="w-full mt-2 bg-gradient-to-r from-blue-500 to-purple-500">
                    Back to Main Site
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  );
}