import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface AISuggestionOptions {
  context: string;
  contentType?: string;
  count?: number;
}

export interface AISuggestionResponse {
  suggestions: string[];
  error?: string;
}

export function useAiSuggestions() {
  const { mutateAsync, isPending, isError, error } = useMutation({
    mutationFn: async ({ context, contentType = "general", count = 3 }: AISuggestionOptions): Promise<AISuggestionResponse> => {
      try {
        const response = await apiRequest("POST", "/api/ai/suggestions", {
          context,
          contentType,
          count
        });
        
        return await response.json();
      } catch (err) {
        console.error("Error getting AI suggestions:", err);
        return { 
          suggestions: [],
          error: err instanceof Error ? err.message : "Failed to get AI suggestions"
        };
      }
    }
  });

  const getSuggestions = async (options: AISuggestionOptions) => {
    try {
      return await mutateAsync(options);
    } catch (err) {
      console.error("Error in getSuggestions:", err);
      return { suggestions: [], error: "Failed to get suggestions" };
    }
  };

  return {
    getSuggestions,
    isLoading: isPending,
    isError,
    error
  };
}